--[[
    Espresso's Synapse Blue UI
    Pwease Don't Skid!!!
]]

local Converted = {
	["_IrisOS"] = Instance.new("ScreenGui");
	["_Main"] = Instance.new("Frame");
	["_topbar"] = Instance.new("Frame");
	["_ImageLabel"] = Instance.new("ImageLabel");
	["_TextButton"] = Instance.new("TextButton");
	["_TextButton1"] = Instance.new("TextButton");
	["_LocalScript"] = Instance.new("LocalScript");
	["_LocalScript1"] = Instance.new("LocalScript");
	["_sidebart"] = Instance.new("Frame");
	["_Tab1"] = Instance.new("Frame");
	["_ImageButton"] = Instance.new("ImageButton");
	["_LocalScript2"] = Instance.new("LocalScript");
	["_Tab2"] = Instance.new("Frame");
	["_ImageButton1"] = Instance.new("ImageButton");
	["_LocalScript3"] = Instance.new("LocalScript");
	["_Tab3"] = Instance.new("Frame");
	["_ImageButton2"] = Instance.new("ImageButton");
	["_LocalScript4"] = Instance.new("LocalScript");
	["_Tab4"] = Instance.new("Frame");
	["_ImageButton3"] = Instance.new("ImageButton");
	["_Executor"] = Instance.new("Frame");
	["_Editor"] = Instance.new("ScrollingFrame");
	["_TextBox"] = Instance.new("ScrollingFrame");
	["_Source"] = Instance.new("TextBox");
	["_Script"] = Instance.new("Script");
	["_LocalScript5"] = Instance.new("LocalScript");
	["_RemoteEvent"] = Instance.new("RemoteEvent");
	["_Tokens_"] = Instance.new("TextLabel");
	["_Numbers_"] = Instance.new("TextLabel");
	["_Keywords_"] = Instance.new("TextLabel");
	["_Globals_"] = Instance.new("TextLabel");
	["_Strings_"] = Instance.new("TextLabel");
	["_Comments_"] = Instance.new("TextLabel");
	["_Vars_"] = Instance.new("TextLabel");
	["_Main1"] = Instance.new("LocalScript");
	["_SourceText"] = Instance.new("StringValue");
	["_UIListLayout"] = Instance.new("UIListLayout");
	["_Lines"] = Instance.new("TextLabel");
	["_taskbar"] = Instance.new("Frame");
	["_TextButton2"] = Instance.new("TextButton");
	["_LocalScript6"] = Instance.new("LocalScript");
	["_TextButton3"] = Instance.new("TextButton");
	["_LocalScript7"] = Instance.new("LocalScript");
	["_TextButton4"] = Instance.new("TextButton");
	["_LocalScript8"] = Instance.new("LocalScript");
	["_TextButton5"] = Instance.new("TextButton");
	["_LocalScript9"] = Instance.new("LocalScript");
	["_Frame"] = Instance.new("Frame");
	["_ScrollingFrame"] = Instance.new("ScrollingFrame");
	["_UIListLayout1"] = Instance.new("UIListLayout");
	["_TextLabel"] = Instance.new("TextLabel");
	["_Dragify"] = Instance.new("LocalScript");
	["_ScriptHub"] = Instance.new("Frame");
	["_Frame1"] = Instance.new("Frame");
	["_ImageLabel1"] = Instance.new("ImageLabel");
	["_TextButton6"] = Instance.new("TextButton");
	["_Frame2"] = Instance.new("Frame");
	["_ImageLabel2"] = Instance.new("ImageLabel");
	["_TextButton7"] = Instance.new("TextButton");
	["_Frame3"] = Instance.new("Frame");
	["_ImageLabel3"] = Instance.new("ImageLabel");
	["_TextButton8"] = Instance.new("TextButton");
	["_Frame4"] = Instance.new("Frame");
	["_ImageLabel4"] = Instance.new("ImageLabel");
	["_TextButton9"] = Instance.new("TextButton");
	["_TextLabel1"] = Instance.new("TextLabel");
	["_Console"] = Instance.new("Frame");
	["_TextLabel2"] = Instance.new("TextLabel");
	["_TextBox1"] = Instance.new("TextBox");
	["_TextBox2"] = Instance.new("TextBox");
	["_TextButton10"] = Instance.new("TextButton");
	["_CanvasGroup"] = Instance.new("CanvasGroup");
	["_Topbar"] = Instance.new("Frame");
	["_ImageLabel5"] = Instance.new("ImageLabel");
	["_TextLabel3"] = Instance.new("TextLabel");
	["_Progress"] = Instance.new("Frame");
	["_UICorner"] = Instance.new("UICorner");
	["_bar"] = Instance.new("Frame");
	["_UICorner1"] = Instance.new("UICorner");
	["_TextLabel4"] = Instance.new("TextLabel");
	["_TextLabel5"] = Instance.new("TextLabel");
	["_LocalScript10"] = Instance.new("LocalScript");
	["_Hints"] = Instance.new("Frame");
	["_UICorner2"] = Instance.new("UICorner");
	["_TextBox3"] = Instance.new("TextBox");
	["_Circle1"] = Instance.new("Frame");
	["_UICorner3"] = Instance.new("UICorner");
	["_Circle2"] = Instance.new("Frame");
	["_UICorner4"] = Instance.new("UICorner");
	["_Circle3"] = Instance.new("Frame");
	["_UICorner5"] = Instance.new("UICorner");
	["_Circle4"] = Instance.new("Frame");
	["_UICorner6"] = Instance.new("UICorner");
	["_Hide"] = Instance.new("Frame");
	["_LocalScript11"] = Instance.new("LocalScript");
}

-- Properties:

Converted["_IrisOS"].ZIndexBehavior = Enum.ZIndexBehavior.Sibling
Converted["_IrisOS"].Name = "IrisOS"
Converted["_IrisOS"].Parent = game:GetService("CoreGui")

Converted["_Main"].BackgroundColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_Main"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Main"].BorderSizePixel = 0
Converted["_Main"].ClipsDescendants = true
Converted["_Main"].Position = UDim2.new(0.207507402, 0, 0.238643274, 0)
Converted["_Main"].Size = UDim2.new(0, 805, 0, 426)
Converted["_Main"].Visible = false
Converted["_Main"].Name = "Main"
Converted["_Main"].Parent = Converted["_IrisOS"]

Converted["_topbar"].BackgroundColor3 = Color3.fromRGB(28.000000230968, 60.00000022351742, 164.00000542402267)
Converted["_topbar"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_topbar"].BorderSizePixel = 0
Converted["_topbar"].Size = UDim2.new(0, 805, 0, 58)
Converted["_topbar"].Name = "topbar"
Converted["_topbar"].Parent = Converted["_Main"]

Converted["_ImageLabel"].Image = "http://www.roblox.com/asset/?id=1505584527"
Converted["_ImageLabel"].ScaleType = Enum.ScaleType.Fit
Converted["_ImageLabel"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel"].BackgroundTransparency = 1
Converted["_ImageLabel"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel"].BorderSizePixel = 0
Converted["_ImageLabel"].Position = UDim2.new(0.00993788801, 0, 0.068965517, 0)
Converted["_ImageLabel"].Size = UDim2.new(0, 187, 0, 49)
Converted["_ImageLabel"].Parent = Converted["_topbar"]

Converted["_TextButton"].Font = Enum.Font.Ubuntu
Converted["_TextButton"].Text = "X"
Converted["_TextButton"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton"].TextSize = 14
Converted["_TextButton"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton"].BackgroundTransparency = 1
Converted["_TextButton"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextButton"].BorderSizePixel = 0
Converted["_TextButton"].Position = UDim2.new(0.973913014, 0, 0, 0)
Converted["_TextButton"].Size = UDim2.new(0, 21, 0, 18)
Converted["_TextButton"].Parent = Converted["_topbar"]

Converted["_TextButton1"].Font = Enum.Font.Ubuntu
Converted["_TextButton1"].Text = "_"
Converted["_TextButton1"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton1"].TextSize = 14
Converted["_TextButton1"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton1"].BackgroundTransparency = 1
Converted["_TextButton1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextButton1"].BorderSizePixel = 0
Converted["_TextButton1"].Position = UDim2.new(0.947826087, 0, 0, 0)
Converted["_TextButton1"].Size = UDim2.new(0, 21, 0, 18)
Converted["_TextButton1"].Parent = Converted["_topbar"]

Converted["_sidebart"].BackgroundColor3 = Color3.fromRGB(59.00000028312206, 57.00000040233135, 59.00000028312206)
Converted["_sidebart"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_sidebart"].BorderSizePixel = 0
Converted["_sidebart"].Position = UDim2.new(0, 0, 0.136150241, 0)
Converted["_sidebart"].Size = UDim2.new(0, 70, 0, 368)
Converted["_sidebart"].Name = "sidebart"
Converted["_sidebart"].Parent = Converted["_Main"]

Converted["_Tab1"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_Tab1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Tab1"].BorderSizePixel = 0
Converted["_Tab1"].Size = UDim2.new(0, 70, 0, 69)
Converted["_Tab1"].Name = "Tab1"
Converted["_Tab1"].Parent = Converted["_sidebart"]

Converted["_ImageButton"].Image = "rbxassetid://14380265060"
Converted["_ImageButton"].ScaleType = Enum.ScaleType.Fit
Converted["_ImageButton"].SliceCenter = Rect.new(11, 33, 33, 33)
Converted["_ImageButton"].SliceScale = 33
Converted["_ImageButton"].AutoButtonColor = false
Converted["_ImageButton"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_ImageButton"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageButton"].BorderSizePixel = 0
Converted["_ImageButton"].Position = UDim2.new(0.142857149, 0, 0.144927531, 0)
Converted["_ImageButton"].Size = UDim2.new(0, 50, 0, 48)
Converted["_ImageButton"].Parent = Converted["_Tab1"]

Converted["_Tab2"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_Tab2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Tab2"].BorderSizePixel = 0
Converted["_Tab2"].Position = UDim2.new(0, 0, 0.1875, 0)
Converted["_Tab2"].Size = UDim2.new(0, 70, 0, 69)
Converted["_Tab2"].Name = "Tab2"
Converted["_Tab2"].Parent = Converted["_sidebart"]

Converted["_ImageButton1"].Image = "rbxassetid://14380349733"
Converted["_ImageButton1"].ScaleType = Enum.ScaleType.Fit
Converted["_ImageButton1"].SliceCenter = Rect.new(11, 33, 33, 33)
Converted["_ImageButton1"].SliceScale = 33
Converted["_ImageButton1"].AutoButtonColor = false
Converted["_ImageButton1"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_ImageButton1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageButton1"].BorderSizePixel = 0
Converted["_ImageButton1"].Position = UDim2.new(0.200000003, 0, 0.246376812, 0)
Converted["_ImageButton1"].Size = UDim2.new(0, 41, 0, 35)
Converted["_ImageButton1"].Parent = Converted["_Tab2"]

Converted["_Tab3"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_Tab3"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Tab3"].BorderSizePixel = 0
Converted["_Tab3"].Position = UDim2.new(0, 0, 0.375, 0)
Converted["_Tab3"].Size = UDim2.new(0, 70, 0, 69)
Converted["_Tab3"].Name = "Tab3"
Converted["_Tab3"].Parent = Converted["_sidebart"]

Converted["_ImageButton2"].Image = "rbxassetid://14380353212"
Converted["_ImageButton2"].ScaleType = Enum.ScaleType.Fit
Converted["_ImageButton2"].SliceCenter = Rect.new(11, 33, 33, 33)
Converted["_ImageButton2"].SliceScale = 33
Converted["_ImageButton2"].AutoButtonColor = false
Converted["_ImageButton2"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_ImageButton2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageButton2"].BorderSizePixel = 0
Converted["_ImageButton2"].Position = UDim2.new(0.200000003, 0, 0.246376812, 0)
Converted["_ImageButton2"].Size = UDim2.new(0, 41, 0, 35)
Converted["_ImageButton2"].Parent = Converted["_Tab3"]

Converted["_Tab4"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_Tab4"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Tab4"].BorderSizePixel = 0
Converted["_Tab4"].Position = UDim2.new(-0.0142857144, 0, 0.5625, 0)
Converted["_Tab4"].Size = UDim2.new(0, 70, 0, 69)
Converted["_Tab4"].Name = "Tab4"
Converted["_Tab4"].Parent = Converted["_sidebart"]

Converted["_ImageButton3"].Image = "rbxassetid://14380355986"
Converted["_ImageButton3"].ScaleType = Enum.ScaleType.Fit
Converted["_ImageButton3"].SliceCenter = Rect.new(11, 33, 33, 33)
Converted["_ImageButton3"].SliceScale = 33
Converted["_ImageButton3"].AutoButtonColor = false
Converted["_ImageButton3"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_ImageButton3"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageButton3"].BorderSizePixel = 0
Converted["_ImageButton3"].Position = UDim2.new(0.200000003, 0, 0.246376812, 0)
Converted["_ImageButton3"].Size = UDim2.new(0, 41, 0, 35)
Converted["_ImageButton3"].Parent = Converted["_Tab4"]

Converted["_Executor"].BackgroundColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_Executor"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Executor"].BorderSizePixel = 0
Converted["_Executor"].ClipsDescendants = true
Converted["_Executor"].Position = UDim2.new(0.0857142881, 0, 0.136150241, 0)
Converted["_Executor"].Selectable = true
Converted["_Executor"].Size = UDim2.new(0, 736, 0, 368)
Converted["_Executor"].Name = "Executor"
Converted["_Executor"].Parent = Converted["_Main"]

Converted["_Editor"].ScrollBarImageColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Editor"].Active = true
Converted["_Editor"].BackgroundColor3 = Color3.fromRGB(54.00000058114529, 54.00000058114529, 54.00000058114529)
Converted["_Editor"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Editor"].BorderSizePixel = 0
Converted["_Editor"].Position = UDim2.new(0.00951086916, 0, 0.114130437, 0)
Converted["_Editor"].Size = UDim2.new(0, 567, 0, 272)
Converted["_Editor"].Name = "Editor"
Converted["_Editor"].Parent = Converted["_Executor"]

Converted["_TextBox"].BottomImage = "rbxassetid://148970562"
Converted["_TextBox"].CanvasSize = UDim2.new(0, 908, 0, 180)
Converted["_TextBox"].HorizontalScrollBarInset = Enum.ScrollBarInset.ScrollBar
Converted["_TextBox"].MidImage = "rbxassetid://148970562"
Converted["_TextBox"].ScrollBarThickness = 5
Converted["_TextBox"].TopImage = "rbxassetid://148970562"
Converted["_TextBox"].BackgroundColor3 = Color3.fromRGB(54.00000058114529, 54.00000058114529, 54.00000058114529)
Converted["_TextBox"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextBox"].Position = UDim2.new(0.0360657237, 0, 3.63304508e-07, 0)
Converted["_TextBox"].Size = UDim2.new(0.948086798, 0, 4.27646065, 0)
Converted["_TextBox"].ZIndex = 3
Converted["_TextBox"].Name = "TextBox"
Converted["_TextBox"].Parent = Converted["_Editor"]

Converted["_Source"].ClearTextOnFocus = false
Converted["_Source"].Font = Enum.Font.Code
Converted["_Source"].MultiLine = true
Converted["_Source"].PlaceholderColor3 = Color3.fromRGB(204.0000182390213, 204.0000182390213, 204.0000182390213)
Converted["_Source"].RichText = true
Converted["_Source"].Text = ""
Converted["_Source"].TextColor3 = Color3.fromRGB(204.0000182390213, 204.0000182390213, 204.0000182390213)
Converted["_Source"].TextSize = 15
Converted["_Source"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_Source"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_Source"].BackgroundColor3 = Color3.fromRGB(54.00000058114529, 54.00000058114529, 54.00000058114529)
Converted["_Source"].BackgroundTransparency = 1
Converted["_Source"].BorderSizePixel = 0
Converted["_Source"].Size = UDim2.new(1, 0, 1, 0)
Converted["_Source"].ZIndex = 3
Converted["_Source"].Name = "Source"
Converted["_Source"].Parent = Converted["_TextBox"]

Converted["_Script"].Parent = Converted["_Source"]

Converted["_RemoteEvent"].Parent = Converted["_Source"]

Converted["_Tokens_"].Font = Enum.Font.Code
Converted["_Tokens_"].Text = ""
Converted["_Tokens_"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Tokens_"].TextSize = 15
Converted["_Tokens_"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_Tokens_"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_Tokens_"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Tokens_"].BackgroundTransparency = 1
Converted["_Tokens_"].BorderSizePixel = 0
Converted["_Tokens_"].Size = UDim2.new(1, 0, 1, 0)
Converted["_Tokens_"].ZIndex = 5
Converted["_Tokens_"].Name = "Tokens_"
Converted["_Tokens_"].Parent = Converted["_Source"]

Converted["_Numbers_"].Font = Enum.Font.Code
Converted["_Numbers_"].Text = ""
Converted["_Numbers_"].TextColor3 = Color3.fromRGB(255, 157.0000058412552, 44.000001177191734)
Converted["_Numbers_"].TextSize = 15
Converted["_Numbers_"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_Numbers_"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_Numbers_"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Numbers_"].BackgroundTransparency = 1
Converted["_Numbers_"].BorderSizePixel = 0
Converted["_Numbers_"].Size = UDim2.new(1, 0, 1, 0)
Converted["_Numbers_"].ZIndex = 4
Converted["_Numbers_"].Name = "Numbers_"
Converted["_Numbers_"].Parent = Converted["_Source"]

Converted["_Keywords_"].Font = Enum.Font.Code
Converted["_Keywords_"].Text = ""
Converted["_Keywords_"].TextColor3 = Color3.fromRGB(90.00000223517418, 87.00000241398811, 179.000004529953)
Converted["_Keywords_"].TextSize = 15
Converted["_Keywords_"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_Keywords_"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_Keywords_"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Keywords_"].BackgroundTransparency = 1
Converted["_Keywords_"].BorderSizePixel = 0
Converted["_Keywords_"].Size = UDim2.new(1, 0, 1, 0)
Converted["_Keywords_"].ZIndex = 5
Converted["_Keywords_"].Name = "Keywords_"
Converted["_Keywords_"].Parent = Converted["_Source"]

Converted["_Globals_"].Font = Enum.Font.Code
Converted["_Globals_"].Text = ""
Converted["_Globals_"].TextColor3 = Color3.fromRGB(72.00000330805779, 170.0000050663948, 154.00000602006912)
Converted["_Globals_"].TextSize = 15
Converted["_Globals_"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_Globals_"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_Globals_"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Globals_"].BackgroundTransparency = 1
Converted["_Globals_"].BorderSizePixel = 0
Converted["_Globals_"].Size = UDim2.new(1, 0, 1, 0)
Converted["_Globals_"].ZIndex = 5
Converted["_Globals_"].Name = "Globals_"
Converted["_Globals_"].Parent = Converted["_Source"]

Converted["_Strings_"].Font = Enum.Font.Code
Converted["_Strings_"].Text = ""
Converted["_Strings_"].TextColor3 = Color3.fromRGB(173.00000488758087, 241.00001603364944, 149.00000631809235)
Converted["_Strings_"].TextSize = 15
Converted["_Strings_"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_Strings_"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_Strings_"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Strings_"].BackgroundTransparency = 1
Converted["_Strings_"].BorderSizePixel = 0
Converted["_Strings_"].Size = UDim2.new(1, 0, 1, 0)
Converted["_Strings_"].ZIndex = 5
Converted["_Strings_"].Name = "Strings_"
Converted["_Strings_"].Parent = Converted["_Source"]

Converted["_Comments_"].Font = Enum.Font.Code
Converted["_Comments_"].Text = ""
Converted["_Comments_"].TextColor3 = Color3.fromRGB(134.00000721216202, 131.00000739097595, 124.00000780820847)
Converted["_Comments_"].TextSize = 15
Converted["_Comments_"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_Comments_"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_Comments_"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Comments_"].BackgroundTransparency = 1
Converted["_Comments_"].BorderSizePixel = 0
Converted["_Comments_"].Size = UDim2.new(1, 0, 1, 0)
Converted["_Comments_"].ZIndex = 5
Converted["_Comments_"].Name = "Comments_"
Converted["_Comments_"].Parent = Converted["_Source"]

Converted["_Vars_"].Font = Enum.Font.Code
Converted["_Vars_"].Text = ""
Converted["_Vars_"].TextColor3 = Color3.fromRGB(132.0000073313713, 214.00001764297485, 247.00001567602158)
Converted["_Vars_"].TextSize = 15
Converted["_Vars_"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_Vars_"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_Vars_"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Vars_"].BackgroundTransparency = 1
Converted["_Vars_"].BorderSizePixel = 0
Converted["_Vars_"].Size = UDim2.new(1, 0, 1, 0)
Converted["_Vars_"].ZIndex = 5
Converted["_Vars_"].Name = "Vars_"
Converted["_Vars_"].Parent = Converted["_Source"]

Converted["_SourceText"].Name = "SourceText"
Converted["_SourceText"].Parent = Converted["_TextBox"]

Converted["_UIListLayout"].SortOrder = Enum.SortOrder.LayoutOrder
Converted["_UIListLayout"].VerticalAlignment = Enum.VerticalAlignment.Center
Converted["_UIListLayout"].Parent = Converted["_TextBox"]

Converted["_Lines"].Font = Enum.Font.Code
Converted["_Lines"].Text = "1"
Converted["_Lines"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_Lines"].TextSize = 15
Converted["_Lines"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_Lines"].Active = true
Converted["_Lines"].BackgroundColor3 = Color3.fromRGB(63.000000044703484, 63.000000044703484, 63.000000044703484)
Converted["_Lines"].BorderSizePixel = 0
Converted["_Lines"].Position = UDim2.new(0, 0, -0.000247969409, 0)
Converted["_Lines"].Size = UDim2.new(0.0360655747, 0, 23.9437981, 0)
Converted["_Lines"].ZIndex = 4
Converted["_Lines"].Name = "Lines"
Converted["_Lines"].Parent = Converted["_Editor"]

Converted["_taskbar"].BackgroundColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_taskbar"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_taskbar"].BorderSizePixel = 0
Converted["_taskbar"].Position = UDim2.new(-0.00230540405, 0, 0.999000013, 1)
Converted["_taskbar"].Selectable = true
Converted["_taskbar"].Size = UDim2.new(0, 736, 0, -54)
Converted["_taskbar"].SizeConstraint = Enum.SizeConstraint.RelativeXX
Converted["_taskbar"].Name = "taskbar"
Converted["_taskbar"].Parent = Converted["_Executor"]

Converted["_TextButton2"].Font = Enum.Font.Ubuntu
Converted["_TextButton2"].Text = "Execute"
Converted["_TextButton2"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton2"].TextSize = 16
Converted["_TextButton2"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_TextButton2"].BorderColor3 = Color3.fromRGB(118.00000816583633, 118.00000816583633, 118.00000816583633)
Converted["_TextButton2"].Position = UDim2.new(0.0118162734, 0, 0.227407947, 0)
Converted["_TextButton2"].Size = UDim2.new(0, 116, 0, 35)
Converted["_TextButton2"].Parent = Converted["_taskbar"]

Converted["_TextButton3"].Font = Enum.Font.Ubuntu
Converted["_TextButton3"].Text = "Clear"
Converted["_TextButton3"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton3"].TextSize = 16
Converted["_TextButton3"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_TextButton3"].BorderColor3 = Color3.fromRGB(118.00000816583633, 118.00000816583633, 118.00000816583633)
Converted["_TextButton3"].Position = UDim2.new(0.184059307, 0, 0.227407947, 0)
Converted["_TextButton3"].Size = UDim2.new(0, 116, 0, 35)
Converted["_TextButton3"].Parent = Converted["_taskbar"]

Converted["_TextButton4"].Font = Enum.Font.Ubuntu
Converted["_TextButton4"].Text = "Save File"
Converted["_TextButton4"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton4"].TextSize = 16
Converted["_TextButton4"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_TextButton4"].BorderColor3 = Color3.fromRGB(118.00000816583633, 118.00000816583633, 118.00000816583633)
Converted["_TextButton4"].Position = UDim2.new(0.357490122, 0, 0.227407947, 0)
Converted["_TextButton4"].Size = UDim2.new(0, 116, 0, 35)
Converted["_TextButton4"].Parent = Converted["_taskbar"]

Converted["_TextButton5"].Font = Enum.Font.Ubuntu
Converted["_TextButton5"].Text = "Open FIle"
Converted["_TextButton5"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton5"].TextSize = 16
Converted["_TextButton5"].BackgroundColor3 = Color3.fromRGB(72.00000330805779, 69.00000348687172, 72.00000330805779)
Converted["_TextButton5"].BorderColor3 = Color3.fromRGB(118.00000816583633, 118.00000816583633, 118.00000816583633)
Converted["_TextButton5"].Position = UDim2.new(0.530813456, 0, 0.227407947, 0)
Converted["_TextButton5"].Size = UDim2.new(0, 116, 0, 35)
Converted["_TextButton5"].Parent = Converted["_taskbar"]

Converted["_Frame"].BackgroundColor3 = Color3.fromRGB(54.00000058114529, 54.00000058114529, 54.00000058114529)
Converted["_Frame"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Frame"].BorderSizePixel = 0
Converted["_Frame"].ClipsDescendants = true
Converted["_Frame"].Position = UDim2.new(0.794836938, 0, 0.0271739122, 0)
Converted["_Frame"].Size = UDim2.new(0, 143, 0, 304)
Converted["_Frame"].Parent = Converted["_Executor"]

Converted["_ScrollingFrame"].ScrollBarImageColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ScrollingFrame"].Active = true
Converted["_ScrollingFrame"].BackgroundColor3 = Color3.fromRGB(54.00000058114529, 54.00000058114529, 54.00000058114529)
Converted["_ScrollingFrame"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ScrollingFrame"].BorderSizePixel = 0
Converted["_ScrollingFrame"].Size = UDim2.new(0, 143, 0, 304)
Converted["_ScrollingFrame"].Parent = Converted["_Frame"]

Converted["_UIListLayout1"].SortOrder = Enum.SortOrder.LayoutOrder
Converted["_UIListLayout1"].Parent = Converted["_ScrollingFrame"]

Converted["_TextLabel"].Font = Enum.Font.Nunito
Converted["_TextLabel"].Text = "Execution"
Converted["_TextLabel"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel"].TextScaled = true
Converted["_TextLabel"].TextSize = 20
Converted["_TextLabel"].TextWrapped = true
Converted["_TextLabel"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel"].BackgroundTransparency = 1
Converted["_TextLabel"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextLabel"].BorderSizePixel = 0
Converted["_TextLabel"].Position = UDim2.new(0.00951086916, 0, 0, 0)
Converted["_TextLabel"].Size = UDim2.new(0, 123, 0, 42)
Converted["_TextLabel"].Parent = Converted["_Executor"]

Converted["_ScriptHub"].BackgroundColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_ScriptHub"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ScriptHub"].BorderSizePixel = 0
Converted["_ScriptHub"].Position = UDim2.new(0.0869565234, 0, 0.136150241, 0)
Converted["_ScriptHub"].Size = UDim2.new(0, 736, 0, 368)
Converted["_ScriptHub"].Visible = false
Converted["_ScriptHub"].Name = "ScriptHub"
Converted["_ScriptHub"].Parent = Converted["_Main"]

Converted["_Frame1"].BackgroundColor3 = Color3.fromRGB(65.0000037252903, 65.0000037252903, 65.0000037252903)
Converted["_Frame1"].BackgroundTransparency = 1
Converted["_Frame1"].BorderColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_Frame1"].BorderSizePixel = 0
Converted["_Frame1"].ClipsDescendants = true
Converted["_Frame1"].Position = UDim2.new(0.00951086916, 0, 0.114130437, 0)
Converted["_Frame1"].Size = UDim2.new(0, 128, 0, 128)
Converted["_Frame1"].Parent = Converted["_ScriptHub"]

Converted["_ImageLabel1"].Image = "rbxassetid://14385788190"
Converted["_ImageLabel1"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel1"].BackgroundTransparency = 1
Converted["_ImageLabel1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel1"].BorderSizePixel = 0
Converted["_ImageLabel1"].Position = UDim2.new(4.76837158e-07, 0, -0.00202322006, 0)
Converted["_ImageLabel1"].Size = UDim2.new(0, 126, 0, 99)
Converted["_ImageLabel1"].Parent = Converted["_Frame1"]

Converted["_TextButton6"].Font = Enum.Font.SourceSans
Converted["_TextButton6"].Text = "Dark Dex"
Converted["_TextButton6"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton6"].TextSize = 14
Converted["_TextButton6"].BackgroundColor3 = Color3.fromRGB(20.000000707805157, 20.000000707805157, 20.000000707805157)
Converted["_TextButton6"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextButton6"].BorderSizePixel = 0
Converted["_TextButton6"].Position = UDim2.new(4.76837158e-07, 0, 0.7734375, 0)
Converted["_TextButton6"].Size = UDim2.new(0, 127, 0, 29)
Converted["_TextButton6"].Parent = Converted["_Frame1"]

Converted["_Frame2"].BackgroundColor3 = Color3.fromRGB(65.0000037252903, 65.0000037252903, 65.0000037252903)
Converted["_Frame2"].BackgroundTransparency = 1
Converted["_Frame2"].BorderColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_Frame2"].BorderSizePixel = 0
Converted["_Frame2"].ClipsDescendants = true
Converted["_Frame2"].Position = UDim2.new(0.0109238829, 135, 0.114130437, 0)
Converted["_Frame2"].Size = UDim2.new(0, 128, 0, 128)
Converted["_Frame2"].Parent = Converted["_ScriptHub"]

Converted["_ImageLabel2"].Image = "rbxassetid://14385810937"
Converted["_ImageLabel2"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel2"].BackgroundTransparency = 1
Converted["_ImageLabel2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel2"].BorderSizePixel = 0
Converted["_ImageLabel2"].Position = UDim2.new(-0.00182199478, 0, -0.00202322006, 0)
Converted["_ImageLabel2"].Size = UDim2.new(0, 128, 0, 98)
Converted["_ImageLabel2"].Parent = Converted["_Frame2"]

Converted["_TextButton7"].Font = Enum.Font.SourceSans
Converted["_TextButton7"].Text = "Unnamed ESP"
Converted["_TextButton7"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton7"].TextSize = 14
Converted["_TextButton7"].BackgroundColor3 = Color3.fromRGB(20.000000707805157, 20.000000707805157, 20.000000707805157)
Converted["_TextButton7"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextButton7"].BorderSizePixel = 0
Converted["_TextButton7"].Position = UDim2.new(4.76837158e-07, 0, 0.7734375, 0)
Converted["_TextButton7"].Size = UDim2.new(0, 127, 0, 29)
Converted["_TextButton7"].Parent = Converted["_Frame2"]

Converted["_Frame3"].BackgroundColor3 = Color3.fromRGB(65.0000037252903, 65.0000037252903, 65.0000037252903)
Converted["_Frame3"].BackgroundTransparency = 1
Converted["_Frame3"].BorderColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_Frame3"].BorderSizePixel = 0
Converted["_Frame3"].ClipsDescendants = true
Converted["_Frame3"].Position = UDim2.new(0.00684787938, 273, 0.114130437, 0)
Converted["_Frame3"].Size = UDim2.new(0, 128, 0, 128)
Converted["_Frame3"].Parent = Converted["_ScriptHub"]

Converted["_ImageLabel3"].Image = "rbxassetid://14385841074"
Converted["_ImageLabel3"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel3"].BackgroundTransparency = 1
Converted["_ImageLabel3"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel3"].BorderSizePixel = 0
Converted["_ImageLabel3"].Position = UDim2.new(0.0263667107, 0, -0.00202322006, 0)
Converted["_ImageLabel3"].Size = UDim2.new(0, 123, 0, 98)
Converted["_ImageLabel3"].Parent = Converted["_Frame3"]

Converted["_TextButton8"].Font = Enum.Font.SourceSans
Converted["_TextButton8"].Text = "Remote Spy"
Converted["_TextButton8"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton8"].TextSize = 14
Converted["_TextButton8"].BackgroundColor3 = Color3.fromRGB(20.000000707805157, 20.000000707805157, 20.000000707805157)
Converted["_TextButton8"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextButton8"].BorderSizePixel = 0
Converted["_TextButton8"].Position = UDim2.new(4.76837158e-07, 0, 0.7734375, 0)
Converted["_TextButton8"].Size = UDim2.new(0, 127, 0, 29)
Converted["_TextButton8"].Parent = Converted["_Frame3"]

Converted["_Frame4"].BackgroundColor3 = Color3.fromRGB(65.0000037252903, 65.0000037252903, 65.0000037252903)
Converted["_Frame4"].BackgroundTransparency = 1
Converted["_Frame4"].BorderColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_Frame4"].BorderSizePixel = 0
Converted["_Frame4"].ClipsDescendants = true
Converted["_Frame4"].Position = UDim2.new(0.564413011, 0, 0.114130437, 0)
Converted["_Frame4"].Size = UDim2.new(0, 128, 0, 128)
Converted["_Frame4"].Parent = Converted["_ScriptHub"]

Converted["_ImageLabel4"].Image = "http://www.roblox.com/asset/?id=11866127566"
Converted["_ImageLabel4"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel4"].BackgroundTransparency = 1
Converted["_ImageLabel4"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel4"].BorderSizePixel = 0
Converted["_ImageLabel4"].Position = UDim2.new(-0.00154066086, 0, -0.00202322006, 0)
Converted["_ImageLabel4"].Size = UDim2.new(0, 127, 0, 99)
Converted["_ImageLabel4"].Parent = Converted["_Frame4"]

Converted["_TextButton9"].Font = Enum.Font.SourceSans
Converted["_TextButton9"].Text = "Infinite Yield"
Converted["_TextButton9"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton9"].TextSize = 14
Converted["_TextButton9"].BackgroundColor3 = Color3.fromRGB(20.000000707805157, 20.000000707805157, 20.000000707805157)
Converted["_TextButton9"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextButton9"].BorderSizePixel = 0
Converted["_TextButton9"].Position = UDim2.new(4.76837158e-07, 0, 0.7734375, 0)
Converted["_TextButton9"].Size = UDim2.new(0, 127, 0, 29)
Converted["_TextButton9"].Parent = Converted["_Frame4"]

Converted["_TextLabel1"].Font = Enum.Font.Nunito
Converted["_TextLabel1"].Text = "Scripts"
Converted["_TextLabel1"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel1"].TextScaled = true
Converted["_TextLabel1"].TextSize = 20
Converted["_TextLabel1"].TextWrapped = true
Converted["_TextLabel1"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel1"].BackgroundTransparency = 1
Converted["_TextLabel1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextLabel1"].BorderSizePixel = 0
Converted["_TextLabel1"].Position = UDim2.new(0.00951086916, 0, -0.00271739135, 0)
Converted["_TextLabel1"].Size = UDim2.new(0, 103, 0, 42)
Converted["_TextLabel1"].Parent = Converted["_ScriptHub"]

Converted["_Console"].BackgroundColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_Console"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Console"].BorderSizePixel = 0
Converted["_Console"].Position = UDim2.new(0.0869565234, 0, 0.136150241, 0)
Converted["_Console"].Size = UDim2.new(0, 735, 0, 368)
Converted["_Console"].Visible = false
Converted["_Console"].Name = "Console"
Converted["_Console"].Parent = Converted["_Main"]

Converted["_TextLabel2"].Font = Enum.Font.Nunito
Converted["_TextLabel2"].Text = "Console"
Converted["_TextLabel2"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel2"].TextScaled = true
Converted["_TextLabel2"].TextSize = 20
Converted["_TextLabel2"].TextWrapped = true
Converted["_TextLabel2"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel2"].BackgroundTransparency = 1
Converted["_TextLabel2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextLabel2"].BorderSizePixel = 0
Converted["_TextLabel2"].Position = UDim2.new(-1.29544005e-05, 0, 0, 0)
Converted["_TextLabel2"].Size = UDim2.new(0, 141, 0, 42)
Converted["_TextLabel2"].Parent = Converted["_Console"]

Converted["_TextBox1"].ClearTextOnFocus = false
Converted["_TextBox1"].Font = Enum.Font.Code
Converted["_TextBox1"].PlaceholderColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextBox1"].ShowNativeInput = false
Converted["_TextBox1"].Text = ""
Converted["_TextBox1"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextBox1"].TextEditable = false
Converted["_TextBox1"].TextSize = 14
Converted["_TextBox1"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_TextBox1"].BackgroundColor3 = Color3.fromRGB(48.000000938773155, 48.000000938773155, 48.000000938773155)
Converted["_TextBox1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextBox1"].BorderSizePixel = 0
Converted["_TextBox1"].Position = UDim2.new(0.0163265299, 0, 0.114130437, 0)
Converted["_TextBox1"].Selectable = false
Converted["_TextBox1"].Size = UDim2.new(0, 714, 0, 280)
Converted["_TextBox1"].Parent = Converted["_Console"]

Converted["_TextBox2"].ClearTextOnFocus = false
Converted["_TextBox2"].Font = Enum.Font.SourceSans
Converted["_TextBox2"].Text = ""
Converted["_TextBox2"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextBox2"].TextSize = 14
Converted["_TextBox2"].TextXAlignment = Enum.TextXAlignment.Right
Converted["_TextBox2"].BackgroundColor3 = Color3.fromRGB(48.000000938773155, 48.000000938773155, 48.000000938773155)
Converted["_TextBox2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextBox2"].BorderSizePixel = 0
Converted["_TextBox2"].Position = UDim2.new(0.170068026, 0, 0.894021749, 0)
Converted["_TextBox2"].Size = UDim2.new(0, 601, 0, 32)
Converted["_TextBox2"].Parent = Converted["_Console"]

Converted["_TextButton10"].Font = Enum.Font.Code
Converted["_TextButton10"].Text = "syn:/global>"
Converted["_TextButton10"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextButton10"].TextSize = 16
Converted["_TextButton10"].AutoButtonColor = false
Converted["_TextButton10"].BackgroundColor3 = Color3.fromRGB(48.000000938773155, 48.000000938773155, 48.000000938773155)
Converted["_TextButton10"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextButton10"].BorderSizePixel = 0
Converted["_TextButton10"].Position = UDim2.new(0.0163265299, 0, 0.894021749, 0)
Converted["_TextButton10"].Size = UDim2.new(0, 107, 0, 32)
Converted["_TextButton10"].Parent = Converted["_Console"]

Converted["_CanvasGroup"].BackgroundColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_CanvasGroup"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_CanvasGroup"].BorderSizePixel = 0
Converted["_CanvasGroup"].Position = UDim2.new(0.310052812, 0, 0.271634609, 0)
Converted["_CanvasGroup"].Size = UDim2.new(0, 278, 0, 379)
Converted["_CanvasGroup"].Parent = Converted["_IrisOS"]

Converted["_Topbar"].BackgroundColor3 = Color3.fromRGB(28.000000230968, 60.00000022351742, 164.00000542402267)
Converted["_Topbar"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Topbar"].BorderSizePixel = 0
Converted["_Topbar"].ClipsDescendants = true
Converted["_Topbar"].Position = UDim2.new(-0.0447938778, 0, -0.0388583802, 0)
Converted["_Topbar"].Rotation = 5
Converted["_Topbar"].Size = UDim2.new(0, 312, 0, 122)
Converted["_Topbar"].Name = "Topbar"
Converted["_Topbar"].Parent = Converted["_CanvasGroup"]

Converted["_ImageLabel5"].Image = "http://www.roblox.com/asset/?id=1505584527"
Converted["_ImageLabel5"].ScaleType = Enum.ScaleType.Fit
Converted["_ImageLabel5"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_ImageLabel5"].BackgroundTransparency = 1
Converted["_ImageLabel5"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_ImageLabel5"].BorderSizePixel = 0
Converted["_ImageLabel5"].Position = UDim2.new(0.0629341006, 0, 0.216724753, 0)
Converted["_ImageLabel5"].Rotation = -5
Converted["_ImageLabel5"].Size = UDim2.new(0, 169, 0, 42)
Converted["_ImageLabel5"].Parent = Converted["_Topbar"]

Converted["_TextLabel3"].Font = Enum.Font.Arial
Converted["_TextLabel3"].Text = "Let's get scripting."
Converted["_TextLabel3"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel3"].TextSize = 20
Converted["_TextLabel3"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel3"].BackgroundTransparency = 1
Converted["_TextLabel3"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextLabel3"].BorderSizePixel = 0
Converted["_TextLabel3"].Position = UDim2.new(0.0694352165, 0, 0.43472746, 0)
Converted["_TextLabel3"].Rotation = -5
Converted["_TextLabel3"].Size = UDim2.new(0, 177, 0, 52)
Converted["_TextLabel3"].Parent = Converted["_Topbar"]

Converted["_Progress"].BackgroundColor3 = Color3.fromRGB(33.00000183284283, 33.00000183284283, 33.00000183284283)
Converted["_Progress"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Progress"].BorderSizePixel = 0
Converted["_Progress"].ClipsDescendants = true
Converted["_Progress"].Position = UDim2.new(0.079136692, 0, 0.414248019, 0)
Converted["_Progress"].Size = UDim2.new(0, 16, 0, 197)
Converted["_Progress"].Name = "Progress"
Converted["_Progress"].Parent = Converted["_CanvasGroup"]

Converted["_UICorner"].Parent = Converted["_Progress"]

Converted["_bar"].BackgroundColor3 = Color3.fromRGB(28.000000230968, 60.00000022351742, 164.00000542402267)
Converted["_bar"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_bar"].BorderSizePixel = 0
Converted["_bar"].Size = UDim2.new(0, 16, 0, 20)
Converted["_bar"].Name = "bar"
Converted["_bar"].Parent = Converted["_Progress"]

Converted["_UICorner1"].Parent = Converted["_bar"]

Converted["_TextLabel4"].Font = Enum.Font.Arial
Converted["_TextLabel4"].Text = "Initializing..."
Converted["_TextLabel4"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel4"].TextSize = 23
Converted["_TextLabel4"].TextWrapped = true
Converted["_TextLabel4"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel4"].BackgroundTransparency = 1
Converted["_TextLabel4"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextLabel4"].BorderSizePixel = 0
Converted["_TextLabel4"].Position = UDim2.new(0, 0, 0.269129276, 0)
Converted["_TextLabel4"].Size = UDim2.new(0, 155, 0, 35)
Converted["_TextLabel4"].Parent = Converted["_CanvasGroup"]

Converted["_TextLabel5"].Font = Enum.Font.Arial
Converted["_TextLabel5"].Text = "This won't take long."
Converted["_TextLabel5"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel5"].TextSize = 16
Converted["_TextLabel5"].TextWrapped = true
Converted["_TextLabel5"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_TextLabel5"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextLabel5"].BackgroundTransparency = 1
Converted["_TextLabel5"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextLabel5"].BorderSizePixel = 0
Converted["_TextLabel5"].Position = UDim2.new(0.079136692, 0, 0.321899742, 0)
Converted["_TextLabel5"].Size = UDim2.new(0, 172, 0, 35)
Converted["_TextLabel5"].Parent = Converted["_CanvasGroup"]

Converted["_Hints"].BackgroundColor3 = Color3.fromRGB(28.000000230968, 60.00000022351742, 164.00000542402267)
Converted["_Hints"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Hints"].BorderSizePixel = 0
Converted["_Hints"].Position = UDim2.new(0.172999978, 0, 0.413762629, 0)
Converted["_Hints"].Size = UDim2.new(0, 163, 0, 58)
Converted["_Hints"].Name = "Hints"
Converted["_Hints"].Parent = Converted["_CanvasGroup"]

Converted["_UICorner2"].Parent = Converted["_Hints"]

Converted["_TextBox3"].ClearTextOnFocus = false
Converted["_TextBox3"].Font = Enum.Font.Ubuntu
Converted["_TextBox3"].ShowNativeInput = false
Converted["_TextBox3"].Text = "Grabbing Data"
Converted["_TextBox3"].TextColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextBox3"].TextEditable = false
Converted["_TextBox3"].TextSize = 14
Converted["_TextBox3"].TextXAlignment = Enum.TextXAlignment.Left
Converted["_TextBox3"].TextYAlignment = Enum.TextYAlignment.Top
Converted["_TextBox3"].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Converted["_TextBox3"].BackgroundTransparency = 1
Converted["_TextBox3"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_TextBox3"].BorderSizePixel = 0
Converted["_TextBox3"].Selectable = false
Converted["_TextBox3"].Size = UDim2.new(0, 163, 0, 58)
Converted["_TextBox3"].Parent = Converted["_Hints"]

Converted["_Circle1"].BackgroundColor3 = Color3.fromRGB(61.00000396370888, 61.00000396370888, 61.00000396370888)
Converted["_Circle1"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Circle1"].BorderSizePixel = 0
Converted["_Circle1"].Position = UDim2.new(0.0683453232, 0, 0.414248019, 0)
Converted["_Circle1"].Size = UDim2.new(0, 22, 0, 20)
Converted["_Circle1"].Name = "Circle1"
Converted["_Circle1"].Parent = Converted["_CanvasGroup"]

Converted["_UICorner3"].CornerRadius = UDim.new(0.5, 8)
Converted["_UICorner3"].Parent = Converted["_Circle1"]

Converted["_Circle2"].BackgroundColor3 = Color3.fromRGB(61.00000396370888, 61.00000396370888, 61.00000396370888)
Converted["_Circle2"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Circle2"].BorderSizePixel = 0
Converted["_Circle2"].Position = UDim2.new(0.0683453232, 0, 0.551451206, 0)
Converted["_Circle2"].Size = UDim2.new(0, 22, 0, 20)
Converted["_Circle2"].Name = "Circle2"
Converted["_Circle2"].Parent = Converted["_CanvasGroup"]

Converted["_UICorner4"].CornerRadius = UDim.new(0.5, 8)
Converted["_UICorner4"].Parent = Converted["_Circle2"]

Converted["_Circle3"].BackgroundColor3 = Color3.fromRGB(61.00000396370888, 61.00000396370888, 61.00000396370888)
Converted["_Circle3"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Circle3"].BorderSizePixel = 0
Converted["_Circle3"].Position = UDim2.new(0.0683453232, 0, 0.704485476, 0)
Converted["_Circle3"].Size = UDim2.new(0, 22, 0, 20)
Converted["_Circle3"].Name = "Circle3"
Converted["_Circle3"].Parent = Converted["_CanvasGroup"]

Converted["_UICorner5"].CornerRadius = UDim.new(0.5, 8)
Converted["_UICorner5"].Parent = Converted["_Circle3"]

Converted["_Circle4"].BackgroundColor3 = Color3.fromRGB(61.00000396370888, 61.00000396370888, 61.00000396370888)
Converted["_Circle4"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Circle4"].BorderSizePixel = 0
Converted["_Circle4"].Position = UDim2.new(0.0683453232, 0, 0.881266475, 0)
Converted["_Circle4"].Size = UDim2.new(0, 22, 0, 20)
Converted["_Circle4"].Name = "Circle4"
Converted["_Circle4"].Parent = Converted["_CanvasGroup"]

Converted["_UICorner6"].CornerRadius = UDim.new(0.5, 8)
Converted["_UICorner6"].Parent = Converted["_Circle4"]

Converted["_Hide"].BackgroundColor3 = Color3.fromRGB(36.00000165402889, 36.00000165402889, 36.00000165402889)
Converted["_Hide"].BorderColor3 = Color3.fromRGB(0, 0, 0)
Converted["_Hide"].BorderSizePixel = 0
Converted["_Hide"].Position = UDim2.new(-0.0774426386, 0, 0.275498927, 0)
Converted["_Hide"].Rotation = 5
Converted["_Hide"].Size = UDim2.new(0, 324, 0, 307)
Converted["_Hide"].Name = "Hide"
Converted["_Hide"].Parent = Converted["_CanvasGroup"]

-- Fake Module Scripts:

local fake_module_scripts = {}


-- Fake Local Scripts:

local function IGFCRF_fake_script() -- Fake Script: StarterGui.IrisOS.Main.topbar.TextButton.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_TextButton1"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local button = script.Parent
	local mainparent = script.Parent.Parent.Parent.Parent.Main
	
	button.MouseButton1Down:Connect(function()
		mainparent.Visible = false
	end)
end
local function JSOCX_fake_script() -- Fake Script: StarterGui.IrisOS.Main.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Main"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local topbar = script.Parent.topbar
	local main = script.Parent
	local sidebar = script.Parent.sidebart
	local execbuttons = script.Parent.Executor.taskbar
	local editor = script.Parent.Executor.Editor
	local execTab = script.Parent.Executor
	
	sidebar.Visible = false
	topbar.Position = UDim2.new(0, 0,-0.136, 0)
	sidebar.Position = UDim2.new(-0.087, 0,0.136, 0)
	main.Position = UDim2.new(0.108, 0,0.183, 0)
	execbuttons.Position = UDim2.new(-0.002, 0,0.999, 60)
	editor.Position = UDim2.new(0.01, 0,0.027, -390)
	
	wait(9)
	
	topbar:TweenPosition(
		UDim2.new(0, 0,0, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		0.5,
		false
	)
	wait(.5)
	sidebar.Visible = true
	sidebar:TweenPosition(
		UDim2.new(0, 0,0.136, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		0.5,
		false
	)
	execTab.Visible = true
	execTab:TweenPosition(
		UDim2.new(0.086, 0,0.136, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		0.5,
		false
	)
	
	wait(.8)
	editor.Visible = true
	editor:TweenPosition(
		UDim2.new(0.01, 0,0.114, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		0.8,
		false
	)
	
	execbuttons.Visible = true
	execbuttons:TweenPosition(
		UDim2.new(-0.002, 0,0.999, 1),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		.8,
		false
	)
end
local function ZSAF_fake_script() -- Fake Script: StarterGui.IrisOS.Main.sidebart.Tab1.ImageButton.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_ImageButton"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local tab = script.Parent.Parent.Parent.Parent.Executor
	local tab2 = script.Parent.Parent.Parent.Parent.ScriptHub
	local tab3 = script.Parent.Parent.Parent.Parent.Console
	
	tab.Position = UDim2.new(0.086, 0,1, 0)
	
	script.Parent.MouseButton1Down:Connect(function()
		tab3:TweenPosition(
			UDim2.new(0.086, 0,1, 0),
			Enum.EasingDirection.Out,
			Enum.EasingStyle.Sine,
			0.4,
			false
		)
		
		tab2:TweenPosition(
			UDim2.new(0.086, 0,1, 0),
			Enum.EasingDirection.Out,
			Enum.EasingStyle.Sine,
			0.4,
			false
		)
		wait(0.4)
		tab2.Visible = false
		tab.Visible = true
		tab:TweenPosition(
			UDim2.new(0.086, 0,0.136, 0),
			Enum.EasingDirection.Out,
			Enum.EasingStyle.Sine,
			0.4,
			false
		)
	end)
end
local function XNOZK_fake_script() -- Fake Script: StarterGui.IrisOS.Main.sidebart.Tab2.ImageButton.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_ImageButton1"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local tab = script.Parent.Parent.Parent.Parent.ScriptHub
	local tab2 = script.Parent.Parent.Parent.Parent.Executor
	local tab3 = script.Parent.Parent.Parent.Parent.Console
	
	tab.Position = UDim2.new(0.086, 0,1, 0)
	
	script.Parent.MouseButton1Down:Connect(function()
		tab3:TweenPosition(
			UDim2.new(0.086, 0,1, 0),
			Enum.EasingDirection.Out,
			Enum.EasingStyle.Sine,
			0.4,
			false
		)
		
		tab2:TweenPosition(
			UDim2.new(0.086, 0,1, 0),
			Enum.EasingDirection.Out,
			Enum.EasingStyle.Sine,
			0.4,
			false
		)
		wait(0.4)
		tab2.Visible = false
		tab.Visible = true
		tab:TweenPosition(
			UDim2.new(0.086, 0,0.136, 0),
			Enum.EasingDirection.Out,
			Enum.EasingStyle.Sine,
			0.4,
			false
		)
	end)
end
local function HRYRMS_fake_script() -- Fake Script: StarterGui.IrisOS.Main.sidebart.Tab3.ImageButton.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_ImageButton2"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local tab = script.Parent.Parent.Parent.Parent.Console
	local tab2 = script.Parent.Parent.Parent.Parent.Executor
	local tab3 = script.Parent.Parent.Parent.Parent.ScriptHub
	
	tab.Position = UDim2.new(0.086, 0,1, 0)
	
	script.Parent.MouseButton1Down:Connect(function()
		tab3:TweenPosition(
			UDim2.new(0.086, 0,1, 0),
			Enum.EasingDirection.Out,
			Enum.EasingStyle.Sine,
			0.4,
			false
		)
	
		tab2:TweenPosition(
			UDim2.new(0.086, 0,1, 0),
			Enum.EasingDirection.Out,
			Enum.EasingStyle.Sine,
			0.4,
			false
		)
		wait(0.4)
		tab2.Visible = false
		tab.Visible = true
		tab:TweenPosition(
			UDim2.new(0.086, 0,0.136, 0),
			Enum.EasingDirection.Out,
			Enum.EasingStyle.Sine,
			0.4,
			false
		)
	end)
end
local function EHFKJ_fake_script() -- Fake Script: StarterGui.IrisOS.Main.Executor.Editor.TextBox.Source.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_Source"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	script.Parent.Changed:Connect(function()
		script.Parent.RemoteEvent:FireServer(script.Parent.Text)
	end)
end
local function ABAWZLG_fake_script() -- Fake Script: StarterGui.IrisOS.Main.Executor.Editor.TextBox.Main
    local script = Instance.new("LocalScript")
    script.Name = "Main"
    script.Parent = Converted["_TextBox"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local settings = {
		Highlight = true; -- Highlight like you know. Script Text color?
		Lines =true; -- The textbox will have some lines like when you press enter.
		Scroll = true; -- So if it has alot of lines and that it gets off the screen this will help.
		HighlightVariables=false;--Highlights the local and global enviorments
		SplitScanLines=false;-- This trick is used to Scan lines instead of the whole source (Breaks multilined strings and comments) 
		WaitIfRendered=true;-- This trick will reduce lag by waiting if the game has rendered
		AutomaticSettingChange=true;--Automatically changes the settings for the best experience
		LoadLexer=true;--Makes one token and creates highlights out of it instead of many tokens (reduce lag)
	}
	local RunService = game:GetService("RunService")
	local Fps=0
	local TimeFunction = RunService:IsRunning() and time or os.clock
	
	local LastIteration, Start
	local FrameUpdateTable = {}
	
	local function HeartbeatUpdate()
		LastIteration = TimeFunction()
		for Index = #FrameUpdateTable, 1, -1 do
			FrameUpdateTable[Index + 1] = FrameUpdateTable[Index] >= LastIteration - 1 and FrameUpdateTable[Index] or nil
		end
	
		FrameUpdateTable[1] = LastIteration
		Fps = tonumber(math.floor(TimeFunction() - Start >= 1 and #FrameUpdateTable or #FrameUpdateTable / (TimeFunction() - Start)))
	end
	
	Start = TimeFunction()
	RunService.Heartbeat:Connect(HeartbeatUpdate)
	
	--[==[
	This syntax is the best syntax on the marketplace
	Only created by MiAiHsIs1226
	-- Credits
	Credits to the lexer module creator
	Credits to MikePetar for scroll
	Credits to me for literally doing nothing
	]==]
	local function parse(tokens)
		local localvarables = {}
		local whitespacecharactersfound=0
		local readabletokens = {}
		local tokennumbers = {}
		for i,v in pairs(tokens) do
			if v.Source == " " then
				whitespacecharactersfound+=1
				continue
			end
			if v.Type=="space" then
				whitespacecharactersfound+=1
				continue
			end
	
			table.insert(readabletokens,v)
			table.insert(tokennumbers,{i})
		end
	
	
		for i,v in pairs(readabletokens) do
			pcall(function()
				if v.Source == "local" then
					local _,name =pcall(function()return readabletokens[i+1].Source;end)
					if _==false then
						error("Syntax Error: Expected more code")
					end
					if name == "function" then
						_,name =pcall(function()return readabletokens[i+2].Source;end)
						if _==false then
							error("Syntax Error: Expected more code")
						end
						if readabletokens[i+2].Type~="iden" then
							error("Syntax Error: Name isnt an idient")
						end
						table.insert(localvarables,{Name = name,Type="Local",Source = "function",number = tokennumbers[i][1]+4})
					else
						table.insert(localvarables,{Name = name,Type="Local",Source = readabletokens[i+3].Source,number = tokennumbers[i]
							[1]+1})
					end
				elseif v.Type == "iden"  then
	
					if readabletokens[i-1] then
						if readabletokens[i-1].Type ~= "keyword" and readabletokens[i-1].Type ~= "symbol"  then
							local source = readabletokens[i+2].Source
							table.insert(localvarables,{Name = v.Source,Type="Global",Source = source;number = tokennumbers[i]
								[1]})  
						elseif readabletokens[i-1].Source=="function" then
							local source = "function"
							table.insert(localvarables,{Name = v.Source,Type="Global",Source = source;number = tokennumbers[i]
								[1]})  
	
						end
					else
						local source = readabletokens[i+2].Source
						table.insert(localvarables,{Name = v.Source,Type="Global",Source = source,number = tokennumbers[i][1]})  
					end
				end
			end)
		end
	
		return (localvarables)
	end
	local function lexerscan(text)
		local lexer = coroutine.wrap(function()
	
			local lexer = {}
	
			local yield, wrap  = coroutine.yield, coroutine.wrap
			local strfind      = string.find
			local strsub       = string.sub
			local append       = table.insert
			local type         = type
	
			local NUMBER1	= "^[%+%-]?%d+%.?%d*[eE][%+%-]?%d+"
			local NUMBER2	= "^[%+%-]?%d+%.?%d*"
			local NUMBER3	= "^0x[%da-fA-F]+"
			local NUMBER4	= "^%d+%.?%d*[eE][%+%-]?%d+"
			local NUMBER5	= "^%d+%.?%d*"
			local IDEN		= "^[%a_][%w_]*"
			local WSPACE	= "^%s+"
			local STRING1	= "^(['\"])%1"							
			local STRING2	= [[^(['"])(\*)%2%1]]
			local STRING3	= [[^(['"]).-[^\](\*)%2%1]]
			local STRING4	= "^(['\"]).-.*"						
			local STRING5	= "^%[(=*)%[.-%]%1%]"					
			local STRING6	= "^%[%[.-.*"							
			local CHAR1		= "^''"
			local CHAR2		= [[^'(\*)%1']]
			local CHAR3		= [[^'.-[^\](\*)%1']]
			local PREPRO	= "^#.-[^\\]\n"
			local MCOMMENT1	= "^%-%-%[(=*)%[.-%]%1%]"				
			local MCOMMENT2	= "^%-%-%[%[.-.*"						
			local SCOMMENT1	= "^%-%-.-\n"							
			local SCOMMENT2	= "^%-%-.-.*"							
	
			local lua_keyword = {
				["and"] = true,  ["break"] = true,  ["do"] = true,      ["else"] = true,      ["elseif"] = true,
				["end"] = true,  ["false"] = true,  ["for"] = true,     ["function"] = true,  ["if"] = true,
				["in"] = true,   ["local"] = true,  ["nil"] = true,     ["not"] = true,       ["while"] = true,
				["or"] = true,   ["repeat"] = true, ["return"] = true,  ["then"] = true,      ["true"] = true,
				["self"] = true, ["until"] = true
			}
	
			local lua_builtin = {
				["assert"] = true;["collectgarbage"] = true;["error"] = true;["_G"] = true;
				["gcinfo"] = true;["getfenv"] = true;["getmetatable"] = true;["ipairs"] = true;
				["loadstring"] = true;["newproxy"] = true;["next"] = true;["pairs"] = true;
				["pcall"] = true;["print"] = true;["rawequal"] = true;["rawget"] = true;["rawset"] = true;
				["select"] = true;["setfenv"] = true;["setmetatable"] = true;["tonumber"] = true;
				["tostring"] = true;["type"] = true;["unpack"] = true;["_VERSION"] = true;["xpcall"] = true;
				["delay"] = true;["elapsedTime"] = true;["require"] = true;["spawn"] = true;["tick"] = true;
				["time"] = true;["typeof"] = true;["UserSettings"] = true;["wait"] = true;["warn"] = true;
				["game"] = true;["Enum"] = true;["script"] = true;["shared"] = true;["workspace"] = true;
				["Axes"] = true;["BrickColor"] = true;["CFrame"] = true;["Color3"] = true;["ColorSequence"] = true;
				["ColorSequenceKeypoint"] = true;["Faces"] = true;["Instance"] = true;["NumberRange"] = true;
				["NumberSequence"] = true;["NumberSequenceKeypoint"] = true;["PhysicalProperties"] = true;
				["Random"] = true;["Ray"] = true;["Rect"] = true;["Region3"] = true;["Region3int16"] = true;
				["TweenInfo"] = true;["UDim"] = true;["UDim2"] = true;["Vector2"] = true;["Vector3"] = true;
				["Vector3int16"] = true;["next"] = true;
				["os"] = true;
				["os.time"] = true;["os.date"] = true;["os.difftime"] = true;
				["debug"] = true;
				["debug.traceback"] = true;["debug.profilebegin"] = true;["debug.profileend"] = true;
				["math"] = true;
				["math.abs"] = true;["math.acos"] = true;["math.asin"] = true;["math.atan"] = true;["math.atan2"] = true;["math.ceil"] = true;["math.clamp"] = true;["math.cos"] = true;["math.cosh"] = true;["math.deg"] = true;["math.exp"] = true;["math.floor"] = true;["math.fmod"] = true;["math.frexp"] = true;["math.ldexp"] = true;["math.log"] = true;["math.log10"] = true;["math.max"] = true;["math.min"] = true;["math.modf"] = true;["math.noise"] = true;["math.pow"] = true;["math.rad"] = true;["math.random"] = true;["math.randomseed"] = true;["math.sign"] = true;["math.sin"] = true;["math.sinh"] = true;["math.sqrt"] = true;["math.tan"] = true;["math.tanh"] = true;
				["coroutine"] = true;
				["coroutine.create"] = true;["coroutine.resume"] = true;["coroutine.running"] = true;["coroutine.status"] = true;["coroutine.wrap"] = true;["coroutine.yield"] = true;
				["string"] = true;
				["string.byte"] = true;["string.char"] = true;["string.dump"] = true;["string.find"] = true;["string.format"] = true;["string.len"] = true;["string.lower"] = true;["string.match"] = true;["string.rep"] = true;["string.reverse"] = true;["string.sub"] = true;["string.upper"] = true;["string.gmatch"] = true;["string.gsub"] = true;
				["table"] = true;
				["table.concat"] = true;["table.insert"] = true;["table.remove"] = true;["table.sort"] = true;
			}
	
			local function tdump(tok)
				return yield(tok, tok)
			end
	
			local function ndump(tok)
				return yield("number", tok)
			end
	
			local function sdump(tok)
				return yield("string", tok)
			end
	
			local function cdump(tok)
				return yield("comment", tok)
			end
	
			local function wsdump(tok)
				return yield("space", tok)
			end
	
			local function lua_vdump(tok)
				if (lua_keyword[tok]) then
					return yield("keyword", tok)
				elseif (lua_builtin[tok]) then
					return yield("builtin", tok)
				else
					return yield("iden", tok)
				end
			end
	
			local lua_matches = {
				{IDEN,      lua_vdump},        -- Indentifiers
				{WSPACE,    wsdump},           -- Whitespace
				{NUMBER3,   ndump},            -- Numbers
				{NUMBER4,   ndump},
				{NUMBER5,   ndump},
				{STRING1,   sdump},            -- Strings
				{STRING2,   sdump},
				{STRING3,   sdump},
				{STRING4,   sdump},
				{STRING5,   sdump},            -- Multiline-Strings
				{STRING6,   sdump},            -- Multiline-Strings
	
				{MCOMMENT1, cdump},            -- Multiline-Comments
				{MCOMMENT2, cdump},			
				{SCOMMENT1, cdump},            -- Singleline-Comments
				{SCOMMENT2, cdump},
	
				{"^==",     tdump},            -- Operators
				{"^~=",     tdump},
				{"^<=",     tdump},
				{"^>=",     tdump},
				{"^%.%.%.", tdump},
				{"^%.%.",   tdump},
				{"^.",      tdump}
			}
	
			local num_lua_matches = #lua_matches
	
	
			--- Create a plain token iterator from a string.
			-- @tparam string s a string.
			function lexer.scan(s)
	
				local function lex(first_arg)
	
					local line_nr = 0
					local sz = #s
					local idx = 1
	
					-- res is the value used to resume the coroutine.
					local function handle_requests(res)
						while (res) do
							local tp = type(res)
							-- Insert a token list:
							if (tp == "table") then
								res = yield("", "")
								for i = 1,#res do
									local t = res[i]
									res = yield(t[1], t[2])
								end
							elseif (tp == "string") then -- Or search up to some special pattern:
								local i1, i2 = strfind(s, res, idx)
								if (i1) then
									local tok = strsub(s, i1, i2)
									idx = (i2 + 1)
									res = yield("", tok)
								else
									res = yield("", "")
									idx = (sz + 1)
								end
							else
								res = yield(line_nr, idx)
							end
						end
					end
	
					handle_requests(first_arg)
					line_nr = 1
	
					while (true) do
	
						if (idx > sz) then
							while (true) do
								handle_requests(yield())
							end
						end
	
						for i = 1,num_lua_matches do
							local m = lua_matches[i]
							local pat = m[1]
							local fun = m[2]
							local findres = {strfind(s, pat, idx)}
							local i1, i2 = findres[1], findres[2]
							if (i1) then
								local tok = strsub(s, i1, i2)
								idx = (i2 + 1)
								lexer.finished = (idx > sz)
								local res = fun(tok, findres)
								if (tok:find("\n")) then
									-- Update line number:
									local _,newlines = tok:gsub("\n", {})
									line_nr = (line_nr + newlines)
								end
								handle_requests(res)
								break
							end
						end
	
					end
	
				end
	
				return wrap(lex)
	
			end
	
			return lexer
		end)()
		local function doesvalueexist(value,tab)
			for i,v in pairs(tab) do
				if v == value then
					return true
				end
			end
			return false or nil
		end
		local symbols = {
			";";
			"^";
			"(";
			")";
			"%";
			"/";
			":";
			"#";
			"-";
			"=";
			"+";
			"{";
			"}";
			"~";
			"<";
			">";
			"*";
			",";
			".";
			"\""}
		local t={}
		local split=text:split("\n")
		if settings.SplitScanLines==true then
			for _, splitv in pairs(text:split("\n")) do 
				for i,v in (lexer.scan(splitv)) do
					local type= i
					if doesvalueexist(type,symbols)  then-- makes the type "symbol" if it is a symbol
						type="symbol"
					end
					table.insert(t,{Type=type,Source=v})
				end
				table.insert(t,{Type="space",Source="\n"})--dont remove this unless you know what you're doing
				if settings.WaitIfRendered then
					game:GetService("RunService").RenderStepped:Wait()
				end
			end
		else
	
			for i,v in (lexer.scan(text)) do
				local type= i
				if doesvalueexist(type,symbols)  then-- makes the type "symbol" if it is a symbol
					type="symbol"
				end
				table.insert(t,{Type=type,Source=v})
				if settings.WaitIfRendered then
					game:GetService("RunService").RenderStepped:Wait()
				end
			end
	
	
	
		end
		return(t)
	end
	local GetTypeToMakeSyntax=function(s,t)
		if type(s)=="string" then
			if t=="var" then
				local tokens=lexerscan(s)
				local r=""
				local variables=parse(tokens)
				local s={}
				for i,v in pairs(variables) do
					s[v.Name]=v
				end
				for i,v in pairs(tokens) do
					if s[v.Source] then
						if tokens[i-1] then
							if tokens[i-1].Source~="." then
								r=r..v.Source
							else
								continue
							end
						else
							r=r..v.Source
						end
					else
						local s=string.gsub(v.Source,"%d",function(c)return string.rep(" ",#c)end)
						local p=string.gsub(s,"%p",function(c)return string.rep(" ",#c)end)
						local a=string.gsub(p,"%a",function(c)return string.rep(" ",#c)end)
						r=r..a
					end
				end
	
				return(r)
			else
				local tokens=lexerscan(s)
				local r=""
				for i,v in pairs(tokens) do
					if v.Type==t then
						r=r..v.Source
					else
						local s=string.gsub(v.Source,"%d",function(c)return string.rep(" ",#c)end)
						local p=string.gsub(s,"%p",function(c)return string.rep(" ",#c)end)
						local a=string.gsub(p,"%a",function(c)return string.rep(" ",#c)end)
						r=r..a
					end
				end
	
				return(r)
			end
		elseif type(s)=="table" then
			if t=="var" then
				local tokens=s
				local r=""
				local variables=parse(tokens)
				local s={}
				for i,v in pairs(variables) do
					s[v.Name]=v
				end
				for i,v in pairs(tokens) do
					if s[v.Source] then
						if tokens[i-1] then
							if tokens[i-1].Source~="." then
								r=r..v.Source
							else
								continue
							end
						else
							r=r..v.Source
						end
					else
						local s=string.gsub(v.Source,"%d",function(c)return string.rep(" ",#c)end)
						local p=string.gsub(s,"%p",function(c)return string.rep(" ",#c)end)
						local a=string.gsub(p,"%a",function(c)return string.rep(" ",#c)end)
						r=r..a
					end
				end
	
				return(r)
			else
				local tokens=s
				local r=""
				for i,v in pairs(tokens) do
					if v.Type==t then
						r=r..v.Source
					else
						local s=string.gsub(v.Source,"%d",function(c)return string.rep(" ",#c)end)
						local p=string.gsub(s,"%p",function(c)return string.rep(" ",#c)end)
						local a=string.gsub(p,"%a",function(c)return string.rep(" ",#c)end)
						r=r..a
					end
				end
	
				return(r)
			end
		end
	end
	
	local L_1_ = script.Parent.Source
	local L_2_ = Vector2.new(0, 0)  
	local L_3_Org = {      "getrawmetatable",       "game",       "workspace",       "script",       "math",       "string",       "table",       "print",       "wait",       "BrickColor",       "Color3",       "next",       "pairs",       "ipairs",       "select",       "unpack",       "Instance",       "Vector2",       "Vector3",       "CFrame",       "Ray",       "UDim2",       "Enum",       "assert",       "error",       "warn",       "tick",       "loadstring",       "_G",       "shared",       "getfenv",       "setfenv",       "newproxy",       "setmetatable",       "getmetatable",       "os",       "debug",       "pcall",       "ypcall",       "xpcall",       "rawequal",       "rawset",       "rawget",       "tonumber",       "tostring",       "type",       "typeof",       "_VERSION",       "coroutine",       "delay",       "require",       "spawn",       "LoadLibrary",       "settings",       "stats",       "time",       "UserSettings",       "version",       "Axes",       "ColorSequence",       "Faces",       "ColorSequenceKeypoint",       "NumberRange",       "NumberSequence",       "NumberSequenceKeypoint",       "gcinfo",       "elapsedTime",       "collectgarbage",       "PhysicalProperties",       "Rect",       "Region3",       "Region3int16",       "UDim",       "Vector2int16",       "Vector3int16" } 
	local L_3_ = {      "getrawmetatable",       "game",       "workspace",       "script",       "math",       "string",       "table",       "print",       "wait",       "BrickColor",       "Color3",       "next",       "pairs",       "ipairs",       "select",       "unpack",       "Instance",       "Vector2",       "Vector3",       "CFrame",       "Ray",       "UDim2",       "Enum",       "assert",       "error",       "warn",       "tick",       "loadstring",       "_G",       "shared",       "getfenv",       "setfenv",       "newproxy",       "setmetatable",       "getmetatable",       "os",       "debug",       "pcall",       "ypcall",       "xpcall",       "rawequal",       "rawset",       "rawget",       "tonumber",       "tostring",       "type",       "typeof",       "_VERSION",       "coroutine",       "delay",       "require",       "spawn",       "LoadLibrary",       "settings",       "stats",       "time",       "UserSettings",       "version",       "Axes",       "ColorSequence",       "Faces",       "ColorSequenceKeypoint",       "NumberRange",       "NumberSequence",       "NumberSequenceKeypoint",       "gcinfo",       "elapsedTime",       "collectgarbage",       "PhysicalProperties",       "Rect",       "Region3",       "Region3int16",       "UDim",       "Vector2int16",       "Vector3int16" } 
	local L_4_ = {       "and",       "break",       "do",       "else",       "elseif",       "end",       "false",       "for",       "function",       "goto",       "if",       "in",       "local",       "nil",       "not",       "or",       "repeat",       "return",       "then",       "true",       "until",       "while" } 
	
	local function L_5_func(L_49_arg1)       
		local L_50_, L_51_ = L_49_arg1.CanvasSize.Y.Offset, L_49_arg1.AbsoluteWindowSize.Y       
		local L_52_ = L_50_ - L_51_       
		if L_52_ < 0 then             
			L_52_ = 0
		end       
		local L_53_ = Vector2.new(L_49_arg1.CanvasPosition.X, L_52_)       
		return L_53_ 
	end 
	local function ofodguisgfhjjksfghkgh(L_49_arg1)       
		local L_50_, L_51_ = L_49_arg1.CanvasSize.X.Offset, L_49_arg1.AbsoluteWindowSize.X       
		local L_52_ = L_50_ - L_51_       
		if L_52_ < 0 then             
			L_52_ = 0
		end       
		local L_53_ = Vector2.new(L_52_,L_49_arg1.CanvasPosition.Y)       
		return L_53_ 
	end 
	local function GetLineSelected(s)
		local text =  s.Text
		local p = s.CursorPosition
		local text2 = ""
		for i = p,1,-1 do
			local c = text:sub(i,i)
			if c == "\n" then
				break
			else
				text2 = text2 .. c
			end
		end
	
		return (text2:reverse())
	end
	
	wait(.2) 
	local L_6_ = 20 
	L_1_:GetPropertyChangedSignal("Text"):Connect(function()
		if settings.Highlight then
			local L_54_ = L_1_.Comments_       
			local L_56_ = L_1_.Tokens_       
			local L_57_ = L_1_.Numbers_       
			local L_58_ = L_1_.Strings_             
			local L_61_ = L_1_.Keywords_       
			local L_62_ = L_1_.Globals_  
			local L_90_ = L_1_.Vars_  
			if settings.LoadLexer then
				local tokens= lexerscan(L_1_.Text) 
				L_54_.Text=GetTypeToMakeSyntax(tokens,"comment")
	
				L_58_.Text=GetTypeToMakeSyntax(tokens,"string")
	
				L_57_.Text=GetTypeToMakeSyntax(tokens,"number")
	
				L_62_.Text=GetTypeToMakeSyntax(tokens,"builtin")
	
				L_56_.Text=GetTypeToMakeSyntax(tokens,"symbol")
	
				L_61_.Text=GetTypeToMakeSyntax(tokens,"keyword")
	
				if settings.HighlightVariables then
					L_90_.Text=GetTypeToMakeSyntax(tokens,"var")
				end
	
			else
				spawn(function()
					L_54_.Text=GetTypeToMakeSyntax(L_1_.Text,"comment")
				end)
				spawn(function()
					L_58_.Text=GetTypeToMakeSyntax(L_1_.Text,"string")
				end)
				spawn(function()
					L_57_.Text=GetTypeToMakeSyntax(L_1_.Text,"number")
				end)
				spawn(function()
					L_62_.Text=GetTypeToMakeSyntax(L_1_.Text,"builtin")
				end)
				spawn(function()
					L_56_.Text=GetTypeToMakeSyntax(L_1_.Text,"symbol")
				end)
				spawn(function()
					L_61_.Text=GetTypeToMakeSyntax(L_1_.Text,"keyword")
				end)
				spawn(function()
					if settings.HighlightVariables then
						L_90_.Text=GetTypeToMakeSyntax(L_1_.Text,"var")
					end
				end)
	
			end
		end
		local L_63_ = 1    
		if settings.Scroll then
			local X = L_1_.TextBounds.X
			L_1_.Parent.CanvasSize = (UDim2.new(0, L_1_.TextBounds.X + 55 + 5, 0, L_1_.TextBounds.Y))   
		end
		if settings.Lines then
			L_1_.Text:gsub('\n', function()             
				L_63_ = L_63_ + 1       end)      
			L_1_.Parent.Parent.Lines.Text = ""       
			for L_64_forvar1 = 1, L_63_ do             
				L_1_.Parent.Parent.Lines.Text = L_1_.Parent.Parent.Lines.Text..L_64_forvar1.."\n"       
			end       
		end
		if settings.Scroll then
			spawn(function()
				if L_1_.Parent.CanvasPosition.X == L_2_.X then
					L_1_.Parent.CanvasPosition = ofodguisgfhjjksfghkgh(L_1_.Parent)  
				else             
					L_2_ = ofodguisgfhjjksfghkgh(L_1_.Parent)   
				end 
			end)
			wait()
			if L_1_.Text:sub(#L_1_.Text,#L_1_.Text) == "\n" then
				L_1_.Parent.CanvasPosition = Vector2.new()
			end
	
			if L_1_.Parent.CanvasPosition.Y == L_2_.Y then
				L_1_.Parent.CanvasPosition = L_5_func(L_1_.Parent)       
			else             
				L_2_ = L_5_func(L_1_.Parent)       
			end 
		end
	
	
	
	end) 
	if settings.Scroll then
		L_1_.MouseWheelBackward:Connect(function(L_65_arg1, L_66_arg2)       
			wait(.1)      
			game.TweenService:Create(L_1_.Parent, TweenInfo.new(.5, Enum.EasingStyle.Quint), {CanvasPosition = L_1_.Parent.CanvasPosition + Vector2.new(0, L_6_)}):Play()
			L_6_ = L_6_ + 5       
			wait(1)       
			L_6_ = L_6_ - 5 	
		end) 
		L_1_.MouseWheelForward:Connect(function(L_67_arg1, L_68_arg2)    
			wait(.1)      
			game.TweenService:Create(L_1_.Parent, TweenInfo.new(.5, Enum.EasingStyle.Quint), {CanvasPosition = L_1_.Parent.CanvasPosition + Vector2.new(0,-L_6_)}):Play()
			L_6_ = L_6_ + 5       
			wait(1)       
			L_6_ = L_6_ - 5 
		end)
	end
	if settings.Lines then
		L_1_.Parent.Parent.Lines.Text.Visible = true
		L_1_.Parent.Parent.Lines.Text.Position = UDim2.new(0, 0,0, 0)
		L_1_.Position = UDim2.new(0,30,0,0)
	else
		L_1_.Position = UDim2.new()
	end
	if settings.AutomaticSettingChange== true then
		
		spawn(function()
			pcall(function()
				while wait(10) do
					settings.Highlight=true
					if Fps>50 then
						settings.SplitScanLines=false
						settings.LoadLexer=false
						settings.WaitIfRendered=false
						
					elseif Fps<60 and Fps>40 then
						settings.SplitScanLines=false
						settings.LoadLexer=true
						settings.WaitIfRendered=true
						settings.HighlightVariables=false
						
					elseif Fps<35 then
						settings.SplitScanLines=true
						settings.LoadLexer=true
						settings.WaitIfRendered=true
						settings.HighlightVariables=false
						
					elseif Fps>10 then
						settings.Highlight=false
					end
				end
			end)
		end)
	end
end
local function EVNOAN_fake_script() -- Fake Script: StarterGui.IrisOS.Main.Executor.taskbar.TextButton.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_TextButton2"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local button = script.Parent
	local textbox = script.Parent.Parent.Parent.Editor.TextBox.Source
	
	button.MouseEnter:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(44,61,77)
	end)
	
	button.MouseLeave:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(72, 69, 72)
	end)
	
	button.MouseButton1Down:Connect(function()
		assert(loadstring(textbox.Text))()
	end)
end
local function COYF_fake_script() -- Fake Script: StarterGui.IrisOS.Main.Executor.taskbar.TextButton.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_TextButton3"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local button = script.Parent
	local textbox = script.Parent.Parent.Parent.Editor.TextBox.Source
	
	button.MouseEnter:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(44,61,77)
	end)
	
	button.MouseLeave:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(72, 69, 72)
	end)
	button.MouseButton1Down:Connect(function()
		assert(loadstring(textbox.Text))()
	end)
end
local function EAWQKB_fake_script() -- Fake Script: StarterGui.IrisOS.Main.Executor.taskbar.TextButton.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_TextButton4"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local button = script.Parent
	
	button.MouseEnter:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(44,61,77)
	end)
	
	button.MouseLeave:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(72, 69, 72)
	end)
end
local function ULWKGJF_fake_script() -- Fake Script: StarterGui.IrisOS.Main.Executor.taskbar.TextButton.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_TextButton5"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local button = script.Parent
	
	button.MouseEnter:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(44,61,77)
	end)
	
	button.MouseLeave:Connect(function()
		button.BackgroundColor3 = Color3.fromRGB(72, 69, 72)
	end)
end
local function AACJ_fake_script() -- Fake Script: StarterGui.IrisOS.Main.Dragify
    local script = Instance.new("LocalScript")
    script.Name = "Dragify"
    script.Parent = Converted["_Main"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local UIS = game:GetService("UserInputService")
	function dragify(Frame)
		dragToggle = nil
		dragSpeed = 15
		dragInput = nil
		dragStart = nil
		dragPos = nil
		function updateInput(input)
			Delta = input.Position - dragStart
			Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + Delta.X, startPos.Y.Scale, startPos.Y.Offset + Delta.Y)
			game:GetService("TweenService"):Create(Frame, TweenInfo.new(0.15), {Position = Position}):Play()
		end
		Frame.InputBegan:Connect(function(input)
			if (input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch) and UIS:GetFocusedTextBox() == nil then
				dragToggle = true
				dragStart = input.Position
				startPos = Frame.Position
				input.Changed:Connect(function()
					if input.UserInputState == Enum.UserInputState.End then
						dragToggle = false
					end
				end)
			end
		end)
		Frame.InputChanged:Connect(function(input)
			if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
				dragInput = input
			end
		end)
		game:GetService("UserInputService").InputChanged:Connect(function(input)
			if input == dragInput and dragToggle then
				updateInput(input)
			end
		end)
	end
	dragify(script.Parent)
	
end
local function TKPJAFX_fake_script() -- Fake Script: StarterGui.IrisOS.CanvasGroup.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_CanvasGroup"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local prog = script.Parent.Progress.bar
	local topbar = script.Parent.Topbar
	local logo = script.Parent.Topbar.ImageLabel
	local slog = script.Parent.Topbar.TextLabel
	local text = script.Parent.Hints
	local hints = script.Parent.Hints.TextBox
	local hide = script.Parent.Hide
	local canvas = script.Parent
	local main = script.Parent.Parent.Main
	local cir1 = script.Parent.Circle1
	local cir2 = script.Parent.Circle2
	local cir3 = script.Parent.Circle3
	local cir4 = script.Parent.Circle4
	
	
	script.Parent.Visible = true
	prog.Size = UDim2.new(0, 16,0, 12)
	topbar.Size = UDim2.new(0, 8,0, 122)
	slog.Position = UDim2.new(-0.495, 0,0.578, 0)
	logo.Position = UDim2.new(-0.505, 0,0.36, 0)
	text.Position = UDim2.new(0.173, 0,0.414, 0)
	topbar.Visible = false
	slog.Visible = false
	logo.Visible = false
	
	wait(1)
	topbar.Visible  = true
	topbar:TweenSize(
		UDim2.new(0, 312,0, 122),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		0.5,
		false
	)
	
	wait(1)
	
	hide:TweenPosition(
		UDim2.new(-1.211, 0,0.21, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		1,
		false
	)
	wait(1)
	hide.Visible = false
	logo.Visible = true
	logo:TweenPosition(
		UDim2.new(0.063, 0,0.217, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		0.5,
		false
	)
	slog.Visible = true
	slog:TweenPosition(
		UDim2.new(0.069, 0,0.435, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		0.5,
		false
	)
	
	hints.Text = "  Checking Status..."
	
	text:TweenPosition(
		UDim2.new(0.173, 0,0.414, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		1,
		false
	)
	prog:TweenSize(
		UDim2.new(0, 16,0, 20),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		1,
		false
	)
	cir1.BackgroundColor3 = Color3.new(0.0470588, 0.0980392, 0.262745)
	wait(1)
	
	hints.Text = "  Checking For Updates..."
	
	text:TweenPosition(
		UDim2.new(0.173, 0,0.551, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		1,
		false
	)
	prog:TweenSize(
		UDim2.new(0, 16,0, 72),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		1,
		false
	)
	cir2.BackgroundColor3 = Color3.new(0.0470588, 0.0980392, 0.262745)
	wait(1)
	hints.Text = "  Checking Whitelist..."
	
	text:TweenPosition(
		UDim2.new(0.173, 0,0.704, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		1,
		false
	)
	prog:TweenSize(
		UDim2.new(0, 16,0, 130),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		1,
		false
	)
	cir3.BackgroundColor3 = Color3.new(0.0470588, 0.0980392, 0.262745)
	wait(1)
	
	hints.Text = "  Initializing Complete"
	
	text:TweenPosition(
		UDim2.new(0.173, 0,0.831, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		1,
		false
	)
	
	prog:TweenSize(
		UDim2.new(0, 16,0, 197),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		1,
		false
	)
	cir4.BackgroundColor3 = Color3.new(0.0470588, 0.0980392, 0.262745)
	wait(1)
	
	topbar:TweenSize(
		UDim2.new(0, 312,0, 122),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		0.5,
		false
	)
	wait(0.5)
	topbar.Visible  = false
	hide.Visible = true
	hide:TweenSizeAndPosition(
		UDim2.new(0, 805,0, 426),
		UDim2.new(-0.077, 0,0.275, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		1,
		false
	)
	canvas:TweenSizeAndPosition(
		UDim2.new(0, 805,0, 426),
		UDim2.new(0.108, 0,0.183, 0),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Sine,
		1,
		false
	)
	
	wait(1.5)
	main.Visible = true
	canvas.Visible = false
end
local function AGXHW_fake_script() -- Fake Script: StarterGui.IrisOS.LocalScript
    local script = Instance.new("LocalScript")
    script.Name = "LocalScript"
    script.Parent = Converted["_IrisOS"]
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

	local load = script.Parent.CanvasGroup
	local main = script.Parent.Main
	load.Visible = true
	main.Visible = false
	main.Executor.taskbar.Visible = false
	main.Executor.Editor.Visible = false
end

coroutine.wrap(IGFCRF_fake_script)()
coroutine.wrap(JSOCX_fake_script)()
coroutine.wrap(ZSAF_fake_script)()
coroutine.wrap(XNOZK_fake_script)()
coroutine.wrap(HRYRMS_fake_script)()
coroutine.wrap(EHFKJ_fake_script)()
coroutine.wrap(ABAWZLG_fake_script)()
coroutine.wrap(EVNOAN_fake_script)()
coroutine.wrap(COYF_fake_script)()
coroutine.wrap(EAWQKB_fake_script)()
coroutine.wrap(ULWKGJF_fake_script)()
coroutine.wrap(AACJ_fake_script)()
coroutine.wrap(TKPJAFX_fake_script)()
coroutine.wrap(AGXHW_fake_script)()