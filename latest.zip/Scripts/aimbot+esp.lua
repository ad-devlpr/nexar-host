local HyperEscapeAimbot = {
	Enabled = false;
	TeamCheck = false;
	WallCheck = false;

	Smoothing = 0;

	AimPart = "Head";
	Keybind = "MouseButton2";

	Fov = 200;

	ShowFov = false;
	------------------------------------------------------------------------------------------------------------------------------------
	Thickness = 1;

	FovFillColor = Color3.fromRGB(100,0,100);
	FovColor = Color3.fromRGB(100,0,100);

	FovFillTransparency = 1;
	FovTransparenct = 0;

	IsAiming =false;
}

game:GetService("StarterGui"):SetCore("SendNotification", {Title = "https://discord.gg/FsApQ7YNTq", Text = "The Discord For More!"})
--[[
Common (may affect up to 1 in 10 people)

  uneven heartbeat (palpitations)

  mood changes or mood swings or changes in personality
  

Uncommon (may affect up to 1 in 100 people) thinking about or feeling like killing yourself

  seeing, feeling, or hearing things that are not real, these are signs of psychosis

  uncontrolled speech and body movements (Tourette's)

  signs of allergy such as rash, itching or hives on the skin, swelling of the face, lips, tongue or other parts of the body, shortness of breath, wheezing or trouble breathing
  

Rare (may affect up to 1 in 1,000 people)

  feeling unusually excited, over-active and un-inhibited (mania)



Very rare (may affect up to 1 in 10,000 people)

  heart attack

  sudden death

  suicidal attempt

  fits (seizures, convulsions epilepsy)

  skin peeling or purplish red patches

  inflammation or blocked arteries in the brain

  temporary paralysis or problems with movement and vision, difficulties in speech (these can be signs of problems with the blood vessels in your brain)

  muscle spasms which you cannot control affecting your eyes, head, neck, body and nervous system

  decrease in number of blood cells (red cells, white cells and platelets) which can make you more likely to get infections, and make you bleed and bruise more easily

  a sudden increase in body temperature, very high blood pressure and severe convulsions ('Neuroleptic Malignant Syndrome'). It is not certain that this side effect is caused by methylphenidate or other drugs that may be taken in combination with methylphenidate.

Not known (frequency cannot be estimated from the available data)

  unwanted thoughts that keep coming back unexplained fainting, chest pain, shortness of breath (these can be signs of heart problems) // Sysguard being patched 

  prolonged erections, sometimes painful or an increased number of erections.


If you have any of the side effects above, see a doctor straight away.
]]
-- Nice and clean
local AimbotV2 = Instance.new("ScreenGui")AimbotV2.Name = "AimbotV2" AimbotV2.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui") AimbotV2.ZIndexBehavior = Enum.ZIndexBehavior.Sibling AimbotV2.ResetOnSpawn = false
local HEAimbotV2 = Instance.new("Frame")HEAimbotV2.Name = "HEAimbotV2" HEAimbotV2.Parent = AimbotV2 HEAimbotV2.BackgroundColor3 = Color3.fromRGB(52, 52, 52) HEAimbotV2.BorderColor3 = Color3.fromRGB(255, 255, 255) HEAimbotV2.Position = UDim2.new(0.284624249, 0, 0.366314173, 0) HEAimbotV2.Size = UDim2.new(0, 241, 0, 291) HEAimbotV2.Active = true HEAimbotV2.Draggable =true 
local Name = Instance.new("TextLabel")Name.Name = "Name" Name.Parent = HEAimbotV2 Name.BackgroundColor3 = Color3.fromRGB(255, 255, 255) Name.BackgroundTransparency = 1.000 Name.BorderColor3 = Color3.fromRGB(0, 0, 0) Name.BorderSizePixel = 0 Name.Position = UDim2.new(0.0829875544, 0, -0.0406635068, 0) Name.Size = UDim2.new(0, 200, 0, 50) Name.Font = Enum.Font.Roboto Name.Text = "Hyper Escape | AimbotV3" Name.TextColor3 = Color3.fromRGB(17, 223, 255) Name.TextSize = 19.000
local Frame = Instance.new("Frame")Frame.Parent = HEAimbotV2 Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255) Frame.BackgroundTransparency = 1.000 Frame.BorderColor3 = Color3.fromRGB(0, 0, 0) Frame.BorderSizePixel = 0 Frame.Position = UDim2.new(0.287999839, 0, 0.105447777, 0) Frame.Size = UDim2.new(0, 100, 0, 115) 
local Enable_Aim = Instance.new("TextButton")Enable_Aim.Name = "Enable_Aim" Enable_Aim.Parent = Frame Enable_Aim.BackgroundColor3 = Color3.fromRGB(52, 52, 52) Enable_Aim.BorderColor3 = Color3.fromRGB(255, 255, 255) Enable_Aim.Position = UDim2.new(-1.59000003, 0, 1.0086956, 0) Enable_Aim.Size = UDim2.new(0, 122, 0, 24) Enable_Aim.Font = Enum.Font.Roboto Enable_Aim.Text = "Enable" Enable_Aim.TextColor3 = Color3.fromRGB(255, 255, 255) Enable_Aim.TextSize = 17.000
local UIListLayout = Instance.new("UIListLayout")UIListLayout.Parent = Frame UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder UIListLayout.Padding = UDim.new(0, 5)
local WallCheck = Instance.new("TextButton")WallCheck.Name = "WallCheck" WallCheck.Parent = Frame WallCheck.BackgroundColor3 = Color3.fromRGB(52, 52, 52) WallCheck.BorderColor3 = Color3.fromRGB(255, 255, 255) WallCheck.Position = UDim2.new(0.234439835, 0, 0.139479905, 0) WallCheck.Size = UDim2.new(0, 122, 0, 24) WallCheck.Font = Enum.Font.Roboto WallCheck.Text = "Wall Check" WallCheck.TextColor3 = Color3.fromRGB(255, 255, 255) WallCheck.TextSize = 17.000
local Teamcheck = Instance.new("TextButton")Teamcheck.Name = "Teamcheck" Teamcheck.Parent = Frame Teamcheck.BackgroundColor3 = Color3.fromRGB(52, 52, 52) Teamcheck.BorderColor3 = Color3.fromRGB(255, 255, 255) Teamcheck.Position = UDim2.new(0.234439835, 0, 0.139479905, 0) Teamcheck.Size = UDim2.new(0, 122, 0, 24) Teamcheck.Font = Enum.Font.Roboto Teamcheck.Text = "Team check" Teamcheck.TextColor3 = Color3.fromRGB(255, 255, 255) Teamcheck.TextSize = 17.000
local ShowFov = Instance.new("TextButton")ShowFov.Name = "ShowFov" ShowFov.Parent = Frame ShowFov.BackgroundColor3 = Color3.fromRGB(52, 52, 52) ShowFov.BorderColor3 = Color3.fromRGB(255, 255, 255) ShowFov.Position = UDim2.new(0.234439835, 0, 0.139479905, 0) ShowFov.Size = UDim2.new(0, 122, 0, 24) ShowFov.Font = Enum.Font.Roboto ShowFov.Text = "Show Fov" ShowFov.TextColor3 = Color3.fromRGB(255, 255, 255) ShowFov.TextSize = 17.000
local Hitpart = Instance.new("TextButton")Hitpart.Name = "Hitpart" Hitpart.Parent = Frame Hitpart.BackgroundColor3 = Color3.fromRGB(52, 52, 52) Hitpart.BorderColor3 = Color3.fromRGB(255, 255, 255) Hitpart.Position = UDim2.new(-1.59000003, 0, 1.0086956, 0) Hitpart.Size = UDim2.new(0, 122, 0, 24) Hitpart.Font = Enum.Font.Roboto Hitpart.Text = "HEAD, torso" Hitpart.TextColor3 = Color3.fromRGB(255, 255, 255) Hitpart.TextSize = 17.000
local TextLabel = Instance.new("TextLabel")TextLabel.Parent = Frame TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255) TextLabel.BackgroundTransparency = 1.000 TextLabel.BorderColor3 = Color3.fromRGB(0, 0, 0) TextLabel.BorderSizePixel = 0 TextLabel.Position = UDim2.new(0.0747231692, 0, -0.0288301352, 0) TextLabel.Size = UDim2.new(0, 100, 0, 17) TextLabel.Font = Enum.Font.Roboto TextLabel.Text = "Smoothing " TextLabel.TextColor3 = Color3.fromRGB(17, 223, 255) TextLabel.TextSize = 17.000
local Smoothing_Num = Instance.new("TextBox")Smoothing_Num.Name = "Smoothing_Num" Smoothing_Num.Parent = Frame Smoothing_Num.BackgroundColor3 = Color3.fromRGB(52, 52, 52) Smoothing_Num.BorderColor3 = Color3.fromRGB(255, 255, 255) Smoothing_Num.Position = UDim2.new(-0.109999999, 0, 0.782608688, 0) Smoothing_Num.Size = UDim2.new(0, 122, 0, 24) Smoothing_Num.ClearTextOnFocus = false Smoothing_Num.Font = Enum.Font.Roboto Smoothing_Num.PlaceholderText = "3 - 0" Smoothing_Num.Text = "0" Smoothing_Num.TextColor3 = Color3.fromRGB(255, 255, 255) Smoothing_Num.TextSize = 14.000
local TextLabel_2 = Instance.new("TextLabel")TextLabel_2.Parent = Frame TextLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255) TextLabel_2.BackgroundTransparency = 1.000 TextLabel_2.BorderColor3 = Color3.fromRGB(0, 0, 0) TextLabel_2.BorderSizePixel = 0 TextLabel_2.Position = UDim2.new(0.0747231692, 0, -0.0288301352, 0) TextLabel_2.Size = UDim2.new(0, 100, 0, 17) TextLabel_2.Font = Enum.Font.Roboto TextLabel_2.Text = "Fov" TextLabel_2.TextColor3 = Color3.fromRGB(17, 223, 255) TextLabel_2.TextSize = 17.000
local FovNumb = Instance.new("TextBox")FovNumb.Name = "FovNumb" FovNumb.Parent = Frame FovNumb.BackgroundColor3 = Color3.fromRGB(52, 52, 52) FovNumb.BorderColor3 = Color3.fromRGB(255, 255, 255) FovNumb.Position = UDim2.new(-0.109999999, 0, 0.782608688, 0) FovNumb.Size = UDim2.new(0, 122, 0, 24) FovNumb.ClearTextOnFocus = false FovNumb.Font = Enum.Font.Roboto FovNumb.PlaceholderText = "350" FovNumb.Text = "200" game:GetService("StarterGui"):SetCore("SendNotification", {Title = "Hope you enjoy!", Text = "By Mick gordon"}) FovNumb.TextColor3 = Color3.fromRGB(255, 255, 255) FovNumb.TextSize = 14.000
local TextBox = Instance.new("TextBox")TextBox.Parent = HEAimbotV2 TextBox.Active = false TextBox.BackgroundColor3 = Color3.fromRGB(255, 255, 255) TextBox.BackgroundTransparency = 1.000 TextBox.BorderColor3 = Color3.fromRGB(0, 0, 0) TextBox.BorderSizePixel = 0 TextBox.Position = UDim2.new(0.0829875544, 0, 0.929825902, 0) TextBox.Size = UDim2.new(0, 200, 0, 23) TextBox.ClearTextOnFocus = false TextBox.Font = Enum.Font.Roboto TextBox.PlaceholderText = "https://discord.gg/FsApQ7YNTq" TextBox.Text = "https://discord.gg/FsApQ7YNTq -ClickMe" TextBox.TextColor3 = Color3.fromRGB(255, 255, 255) TextBox.TextSize = 14.000
Enable_Aim.MouseButton1Click:Connect(function() if HyperEscapeAimbot.Enabled == true then HyperEscapeAimbot.Enabled = false Enable_Aim.BackgroundColor3 = Color3.fromRGB(52,52,52) else HyperEscapeAimbot.Enabled= true Enable_Aim.BackgroundColor3 = Color3.fromRGB(2, 54, 8) end end) WallCheck.MouseButton1Click:Connect(function() if HyperEscapeAimbot.WallCheck == true then HyperEscapeAimbot.WallCheck = false WallCheck.BackgroundColor3 = Color3.fromRGB(52,52,52) else HyperEscapeAimbot.WallCheck = true WallCheck.BackgroundColor3 = Color3.fromRGB(2, 54, 8) end end) Teamcheck.MouseButton1Click:Connect(function() if HyperEscapeAimbot.TeamCheck == true then HyperEscapeAimbot.TeamCheck = false Teamcheck.BackgroundColor3 = Color3.fromRGB(52,52,52) else HyperEscapeAimbot.TeamCheck = true Teamcheck.BackgroundColor3 = Color3.fromRGB(2, 54, 8) end end) ShowFov.MouseButton1Click:Connect(function() if HyperEscapeAimbot.ShowFov ==true then HyperEscapeAimbot.ShowFov = false ShowFov.BackgroundColor3 = Color3.fromRGB(52,52,52) else HyperEscapeAimbot.ShowFov = true ShowFov.BackgroundColor3 = Color3.fromRGB(2, 54, 8) end end) Hitpart.MouseButton1Click:Connect(function() if HyperEscapeAimbot.AimPart == "Head" then Hitpart.Text = "head, Torso" HyperEscapeAimbot.AimPart = "HumanoidRootPart" else Hitpart.Text = "HEAD, torso" HyperEscapeAimbot.AimPart = "Head" end end)
local Fov = Instance.new("ScreenGui")Fov.Name = "Fov" Fov.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui") Fov.ZIndexBehavior = Enum.ZIndexBehavior.Sibling Fov.ResetOnSpawn = false-- i miss you synapse fov
local FOVFFrame = Instance.new("Frame")FOVFFrame.Parent = Fov FOVFFrame.Name = "FOVFFrame" FOVFFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255) FOVFFrame.BorderColor3 = Color3.fromRGB(0, 0, 0) FOVFFrame.BorderSizePixel = 0 FOVFFrame.BackgroundTransparency = 1 FOVFFrame.AnchorPoint = Vector2.new(0.5, 0.5) FOVFFrame.Position = UDim2.new(0.5, 0,0.5, 0) FOVFFrame.Size = UDim2.new(0, HyperEscapeAimbot.Fov, 0, HyperEscapeAimbot.Fov) FOVFFrame.BackgroundTransparency = 1 
local UICorner = Instance.new("UICorner")UICorner.CornerRadius = UDim.new(1, 0) UICorner.Parent = FOVFFrame 
local UIStroke = Instance.new("UIStroke")UIStroke.Color = Color3.fromRGB(100,0,100) UIStroke.Parent = FOVFFrame UIStroke.Thickness = 1 UIStroke.ApplyStrokeMode = "Border"

local PLAYER = game.Players.LocalPlayer
local CurrentCam  = game.Workspace.CurrentCamera
local UIS = game:GetService("UserInputService")
local l_character = PLAYER.Character or PLAYER.CharacterAdded:wait()
local WorldToViewportPoint = CurrentCam.WorldToViewportPoint
local mouseLocation = UIS.GetMouseLocation


function isVisible(p, ...)
	if not (HyperEscapeAimbot.WallCheck == true) then
		return true
	end 
	return #CurrentCam:GetPartsObscuringTarget({ p }, { CurrentCam, PLAYER.Character, ... }) == 0 
end

function CameraGetClosestToMouse(Fov)
	local AimFov = Fov
	local targetPos = nil

	for i,v in pairs (game:GetService("Players"):GetPlayers()) do
		if v ~= PLAYER then
			if HyperEscapeAimbot.TeamCheck == true then
				if v.Character and v.Character:FindFirstChild(HyperEscapeAimbot.AimPart) and v.Character.Humanoid and v.Character.Humanoid.Health > 0 and not (v.Team == PLAYER.Team) then
					local screen_pos, on_screen = WorldToViewportPoint(CurrentCam, v.Character[HyperEscapeAimbot.AimPart].Position)
					local screen_pos_2D = Vector2.new(screen_pos.X, screen_pos.Y)
					local new_magnitude = (screen_pos_2D - mouseLocation(UIS)).Magnitude
					if on_screen and new_magnitude < AimFov and isVisible(v.Character[HyperEscapeAimbot.AimPart].Position, v.Character.Head.Parent) then
						AimFov = new_magnitude
						targetPos = v
					end
				end
			else
				if v.Character and v.Character:FindFirstChild(HyperEscapeAimbot.AimPart) and v.Character.Humanoid and v.Character.Humanoid.Health > 0 then
					local screen_pos, on_screen = WorldToViewportPoint(CurrentCam, v.Character[HyperEscapeAimbot.AimPart].Position)
					local screen_pos_2D = Vector2.new(screen_pos.X, screen_pos.Y)
					local new_magnitude = (screen_pos_2D - mouseLocation(UIS)).Magnitude
					if on_screen and new_magnitude < AimFov and isVisible(v.Character[HyperEscapeAimbot.AimPart].Position, v.Character.Head.Parent) then
						AimFov = new_magnitude
						targetPos = v
					end
				end
			end
		end
	end
	return targetPos
end


local function aimAt(pos, smooth)
	local AimPart = pos.Character:FindFirstChild(HyperEscapeAimbot.AimPart)
	if AimPart then
		local LookAt = nil
		local Distance = math.floor(0.5+(PLAYER.Character:FindFirstChild"HumanoidRootPart".Position - pos.Character:FindFirstChild"HumanoidRootPart".Position).magnitude)
		if Distance > 100  then
			local distChangeBig = Distance / 10
			LookAt = CurrentCam.CFrame:PointToWorldSpace(Vector3.new(0,0,-smooth * distChangeBig)):Lerp(AimPart.Position,.01) -- No one esle do camera smoothing ? tf
		else
			local distChangeSmall = Distance / 10
			LookAt = CurrentCam.CFrame:PointToWorldSpace(Vector3.new(0,0,-smooth * distChangeSmall)):Lerp(AimPart.Position,.01) -- No one esle do camera smoothing ? tf
		end
		CurrentCam.CFrame = CFrame.lookAt(CurrentCam.CFrame.Position, LookAt)
	end
end

game:GetService('RunService').RenderStepped:connect(function()
	if HyperEscapeAimbot.Enabled == true then 
		if UIS:IsMouseButtonPressed(Enum.UserInputType[HyperEscapeAimbot.Keybind]) then
			local _pos = CameraGetClosestToMouse(HyperEscapeAimbot.Fov)
			if _pos then
				aimAt(_pos, HyperEscapeAimbot.Smoothing)
			end
		end
	end 

	if not (FovNumb.Text == "") then
		HyperEscapeAimbot.Fov = tonumber(FovNumb.Text)
	end
	if not (Smoothing_Num.Text == "") then
		HyperEscapeAimbot.Smoothing = tonumber(Smoothing_Num.Text)
	end

	local acc = HyperEscapeAimbot.Smoothing / 2	
	local posd = UIS:GetMouseLocation() 
	FOVFFrame.Position = UDim2.new(0, posd.X, 0, posd.Y - 36)
	FOVFFrame.Size = UDim2.new(0, HyperEscapeAimbot.Fov + acc, 0, HyperEscapeAimbot.Fov + acc)
	FOVFFrame.Visible = HyperEscapeAimbot.ShowFov
	FOVFFrame.BackgroundColor3 = HyperEscapeAimbot.FovFillColor
	FOVFFrame.Transparency = HyperEscapeAimbot.FovFillTransparency

	UIStroke.Color = HyperEscapeAimbot.FovFillColor
	UIStroke.Transparency = HyperEscapeAimbot.FovTransparenct
	UIStroke.Thickness = HyperEscapeAimbot.Thickness
end)

game:GetService("StarterGui"):SetCore("SendNotification", {Title = "Box ESP", Text = "By Mick Gordon"})
game:GetService("StarterGui"):SetCore("SendNotification", {Title = "https://discord.gg/FsApQ7YNTq", Text = "The Discord"})
local HEBOXESP = Instance.new("ScreenGui") HEBOXESP.Name = "HEBOXESP" HEBOXESP.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui") HEBOXESP.ZIndexBehavior = Enum.ZIndexBehavior.Sibling HEBOXESP.ResetOnSpawn = false
local HEBoxes = Instance.new("Frame")HEBoxes.Name = "HEBoxes" HEBoxes.Parent = HEBOXESP HEBoxes.BackgroundColor3 = Color3.fromRGB(52, 52, 52) HEBoxes.BorderColor3 = Color3.fromRGB(255, 255, 255) HEBoxes.Position = UDim2.new(0.117352635, 0, 0.340447158, 0) HEBoxes.Size = UDim2.new(0, 241, 0, 231) HEBoxes.Active = true HEBoxes.Draggable = true
local TextBox = Instance.new("TextBox")TextBox.Parent = HEBoxes TextBox.Active = false TextBox.BackgroundColor3 = Color3.fromRGB(255, 255, 255) TextBox.BackgroundTransparency = 1.000 TextBox.BorderColor3 = Color3.fromRGB(0, 0, 0) TextBox.BorderSizePixel = 0 TextBox.Position = UDim2.new(0.0829875544, 0, 0.823943675, 0) TextBox.Size = UDim2.new(0, 200, 0, 50) TextBox.ClearTextOnFocus = false TextBox.Font = Enum.Font.Roboto TextBox.PlaceholderText = "https://discord.gg/FsApQ7YNTq" TextBox.Text = "https://discord.gg/FsApQ7YNTq -ClickMe" TextBox.TextColor3 = Color3.fromRGB(255, 255, 255) TextBox.TextSize = 14.000
local Frame = Instance.new("Frame")Frame.Parent = HEBoxes Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255) Frame.BackgroundTransparency = 1.000 Frame.BorderColor3 = Color3.fromRGB(0, 0, 0) Frame.BorderSizePixel = 0 Frame.Position = UDim2.new(0.495850623, 0, 0.26418829, 0) Frame.Size = UDim2.new(0, 121, 0, 100)
local UIListLayout = Instance.new("UIListLayout")UIListLayout.Parent = Frame UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder UIListLayout.Padding = UDim.new(0, 5)
local TextLabel = Instance.new("TextLabel")TextLabel.Parent = Frame TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255) TextLabel.BackgroundTransparency = 1.000 TextLabel.BorderColor3 = Color3.fromRGB(0, 0, 0) TextLabel.BorderSizePixel = 0 TextLabel.Position = UDim2.new(0.0829875544, 0, 0.37352246, 0) TextLabel.Size = UDim2.new(0, 100, 0, 17) TextLabel.Font = Enum.Font.Roboto TextLabel.Text = "Info" TextLabel.TextColor3 = Color3.fromRGB(17, 223, 255) TextLabel.TextSize = 17.000
local Showname = Instance.new("TextButton")Showname.Name = "Showname" Showname.Parent = Frame Showname.BackgroundColor3 = Color3.fromRGB(52, 52, 52) Showname.BorderColor3 = Color3.fromRGB(255, 255, 255) Showname.Position = UDim2.new(0.234439835, 0, 0.0661938563, 0) Showname.Size = UDim2.new(0, 100, 0, 24) Showname.Font = Enum.Font.Roboto Showname.Text = "Show name" Showname.TextColor3 = Color3.fromRGB(255, 255, 255) Showname.TextSize = 17.000
local Showdistance = Instance.new("TextButton")Showdistance.Name = "Showdistance" Showdistance.Parent = Frame Showdistance.BackgroundColor3 = Color3.fromRGB(52, 52, 52) Showdistance.BorderColor3 = Color3.fromRGB(255, 255, 255) Showdistance.Position = UDim2.new(0.234439835, 0, 0.139479905, 0) Showdistance.Size = UDim2.new(0, 100, 0, 24) Showdistance.Font = Enum.Font.Roboto Showdistance.Text = "Show distance" Showdistance.TextColor3 = Color3.fromRGB(255, 255, 255) Showdistance.TextSize = 14.000
local HealthType = Instance.new("TextButton")HealthType.Name = "HealthType" HealthType.Parent = Frame HealthType.BackgroundColor3 = Color3.fromRGB(52, 52, 52) HealthType.BorderColor3 = Color3.fromRGB(255, 255, 255) HealthType.Position = UDim2.new(0.234439835, 0, 0.139479905, 0) HealthType.Size = UDim2.new(0, 100, 0, 24) HealthType.Font = Enum.Font.Roboto HealthType.Text = "TEXT, bar, both" HealthType.TextColor3 = Color3.fromRGB(255, 255, 255) HealthType.TextSize = 17.000
local Frame_2 = Instance.new("Frame")Frame_2.Parent = HEBoxes Frame_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255) Frame_2.BackgroundTransparency = 1.000 Frame_2.BorderColor3 = Color3.fromRGB(0, 0, 0) Frame_2.BorderSizePixel = 0 Frame_2.Position = UDim2.new(-0.00207468891, 0, 0.26418829, 0) Frame_2.Size = UDim2.new(0, 121, 0, 150)
local UIListLayout_2 = Instance.new("UIListLayout")UIListLayout_2.Parent = Frame_2 UIListLayout_2.HorizontalAlignment = Enum.HorizontalAlignment.Center UIListLayout_2.SortOrder = Enum.SortOrder.LayoutOrder UIListLayout_2.Padding = UDim.new(0, 5)
local TextLabel_2 = Instance.new("TextLabel")TextLabel_2.Parent = Frame_2 TextLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255) TextLabel_2.BackgroundTransparency = 1.000 TextLabel_2.BorderColor3 = Color3.fromRGB(0, 0, 0) TextLabel_2.BorderSizePixel = 0 TextLabel_2.Position = UDim2.new(0.0829875544, 0, 0.37352246, 0) TextLabel_2.Size = UDim2.new(0, 100, 0, 17) TextLabel_2.Font = Enum.Font.Roboto TextLabel_2.Text = "Show Box" TextLabel_2.TextColor3 = Color3.fromRGB(17, 223, 255) TextLabel_2.TextSize = 17.000
local Boundingbox = Instance.new("TextButton")Boundingbox.Name = "Boundingbox" Boundingbox.Parent = Frame_2 Boundingbox.BackgroundColor3 = Color3.fromRGB(52, 52, 52) Boundingbox.BorderColor3 = Color3.fromRGB(255, 255, 255) Boundingbox.Position = UDim2.new(0.234439835, 0, 0.139479905, 0) Boundingbox.Size = UDim2.new(0, 100, 0, 24) Boundingbox.Font = Enum.Font.Roboto Boundingbox.Text = "Bounding box" Boundingbox.TextColor3 = Color3.fromRGB(255, 255, 255) Boundingbox.TextSize = 17.000
local UseTeamColor = Instance.new("TextButton")UseTeamColor.Name = "UseTeamColor" UseTeamColor.Parent = Frame_2 UseTeamColor.BackgroundColor3 = Color3.fromRGB(52, 52, 52) UseTeamColor.BorderColor3 = Color3.fromRGB(255, 255, 255) UseTeamColor.Position = UDim2.new(0.234439835, 0, 0.139479905, 0) UseTeamColor.Size = UDim2.new(0, 100, 0, 24) UseTeamColor.Font = Enum.Font.Roboto UseTeamColor.Text = "Use TeamColor" UseTeamColor.TextColor3 = Color3.fromRGB(255, 255, 255) UseTeamColor.TextSize = 14.000
local Showhealth = Instance.new("TextButton")Showhealth.Name = "Showhealth" Showhealth.Parent = Frame_2 Showhealth.BackgroundColor3 = Color3.fromRGB(52, 52, 52) Showhealth.BorderColor3 = Color3.fromRGB(255, 255, 255) Showhealth.Position = UDim2.new(0.234439835, 0, 0.139479905, 0) Showhealth.Size = UDim2.new(0, 100, 0, 24) Showhealth.Font = Enum.Font.Roboto Showhealth.Text = "Show health" Showhealth.TextColor3 = Color3.fromRGB(255, 255, 255) Showhealth.TextSize = 17.000
local A = Instance.new("TextLabel")A.Name = "A" A.Parent = HEBoxes A.BackgroundColor3 = Color3.fromRGB(255, 255, 255) A.BackgroundTransparency = 1.000 A.BorderColor3 = Color3.fromRGB(0, 0, 0) A.BorderSizePixel = 0 A.Position = UDim2.new(0.0829875544, 0, -0.0318399332, 0) A.Size = UDim2.new(0, 200, 0, 50) A.Font = Enum.Font.Roboto A.Text = "Hyper Escape | Box ESP" A.TextColor3 = Color3.fromRGB(17, 223, 255) A.TextSize = 19.000
local Frame_3 = Instance.new("Frame")Frame_3.Parent = HEBoxes Frame_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255) Frame_3.BackgroundTransparency = 1.000 Frame_3.BorderColor3 = Color3.fromRGB(0, 0, 0) Frame_3.BorderSizePixel = 0 Frame_3.Position = UDim2.new(0.287999988, 0, 0.150000006, 0) Frame_3.Size = UDim2.new(0, 100, 0, 82)
local UIListLayout_3 = Instance.new("UIListLayout")UIListLayout_3.Parent = Frame_3 UIListLayout_3.HorizontalAlignment = Enum.HorizontalAlignment.Center UIListLayout_3.SortOrder = Enum.SortOrder.LayoutOrder UIListLayout_3.Padding = UDim.new(0, 7)
local EnablTeamCheck = Instance.new("TextButton")EnablTeamCheck.Name = "EnablTeamCheck" EnablTeamCheck.Parent = Frame_3 EnablTeamCheck.BackgroundColor3 = Color3.fromRGB(52, 52, 52) EnablTeamCheck.BorderColor3 = Color3.fromRGB(255, 255, 255) EnablTeamCheck.Position = UDim2.new(0.234439835, 0, 0.139479905, 0) EnablTeamCheck.Size = UDim2.new(0, 122, 0, 24) EnablTeamCheck.Font = Enum.Font.Roboto EnablTeamCheck.Text = "Show Team" EnablTeamCheck.TextColor3 = Color3.fromRGB(255, 255, 255) EnablTeamCheck.TextSize = 17.000
local A_2 = Instance.new("TextLabel")A_2.Name = "A" A_2.Parent = HEBoxes A_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255) A_2.BackgroundTransparency = 1.000 A_2.BorderColor3 = Color3.fromRGB(0, 0, 0) A_2.BorderSizePixel = 0 A_2.Position = UDim2.new(0.46887967, 0, 0.630497932, 0) A_2.Size = UDim2.new(0, 12, 0, 14) A_2.Font = Enum.Font.Roboto A_2.Text = "=" A_2.TextColor3 = Color3.fromRGB(255, 255, 255) A_2.TextSize = 19.000
local localplayer = game:GetService"Players".LocalPlayer

local cheats = {
	Boundingbox = false; 
	Showdistance = false;
	Showname = false; 
	Showhealth = false;
	b_ht = "Bar"; 
	EnablTeamCheck = false; 
	UseTeamColor = false; 
	HealthType = false; 
}

local cheatsf = Instance.new("Folder", game.Workspace) cheatsf.Name = "cheats"
local espf = Instance.new("Folder", cheatsf) espf.Name = "esp"

function AddBox(player)
	local bbg = Instance.new("BillboardGui", espf)
	bbg.Name = player.Name
	bbg.AlwaysOnTop = true
	bbg.Size = UDim2.new(4,0,5.4,0)
	bbg.ClipsDescendants = false

	local outlines = Instance.new("Frame", bbg)
	outlines.Size = UDim2.new(1,0,1,0)
	outlines.BorderSizePixel = 0
	outlines.BackgroundTransparency = 1
	local left = Instance.new("Frame", outlines)
	left.BorderSizePixel = 0
	left.Size = UDim2.new(0,1,1,0)
	local right = left:Clone()
	right.Parent = outlines
	right.Size = UDim2.new(0,-1,1,0)
	right.Position = UDim2.new(1,0,0,0)
	local up = left:Clone()
	up.Parent = outlines
	up.Size = UDim2.new(1,0,0,1)
	local down = left:Clone()
	down.Parent = outlines
	down.Size = UDim2.new(1,0,0,-1)
	down.Position = UDim2.new(0,0,1,0)

	local info = Instance.new("BillboardGui", bbg)
	info.Name = "info"
	info.Size = UDim2.new(3,0,0,54)
	info.StudsOffset = Vector3.new(3.6,-3,0)
	info.AlwaysOnTop = true
	info.ClipsDescendants = false
	local namelabel = Instance.new("TextLabel", info)
	namelabel.Name = "namelabel"
	namelabel.BackgroundTransparency = 1
	namelabel.TextStrokeTransparency = 0
	namelabel.TextXAlignment = Enum.TextXAlignment.Left
	namelabel.Size = UDim2.new(0,100,0,18)
	namelabel.Position = UDim2.new(0,0,0,0)
	namelabel.Text = player.Name
	local distancel = Instance.new("TextLabel", info)
	distancel.Name = "distancelabel"
	distancel.BackgroundTransparency = 1
	distancel.TextStrokeTransparency = 0
	distancel.TextXAlignment = Enum.TextXAlignment.Left
	distancel.Size = UDim2.new(0,100,0,18)
	distancel.Position = UDim2.new(0,0,0,18)
	local healthl = Instance.new("TextLabel", info)
	healthl.Name = "healthlabel"
	healthl.BackgroundTransparency = 1
	healthl.TextStrokeTransparency = 0
	healthl.TextXAlignment = Enum.TextXAlignment.Left
	healthl.Size = UDim2.new(0,100,0,18)
	healthl.Position = UDim2.new(0,0,0,36)

	local uill = Instance.new("UIListLayout", info)

	local forhealth = Instance.new("BillboardGui", bbg)
	forhealth.Name = "forhealth"
	forhealth.Size = UDim2.new(5,0,6,0)
	forhealth.AlwaysOnTop = true
	forhealth.ClipsDescendants = false

	local healthbar = Instance.new("Frame", forhealth)
	healthbar.Name = "healthbar"
	healthbar.BackgroundColor3 = Color3.fromRGB(40,40,40)
	healthbar.BorderColor3 = Color3.fromRGB(0,0,0)
	healthbar.Size = UDim2.new(0.04,0,0.9,0)
	healthbar.Position = UDim2.new(0,0,0.05,0)
	local bar = Instance.new("Frame", healthbar)
	bar.Name = "bar"
	bar.BorderSizePixel = 0
	bar.BackgroundColor3 = Color3.fromRGB(94,255,69)
	bar.AnchorPoint = Vector2.new(0,1)
	bar.Position = UDim2.new(0,0,1,0)
	bar.Size = UDim2.new(1,0,1,0)

	local co = coroutine.create(function()
		while wait(0.1) do
			if (player.Character and player.Character:FindFirstChild"HumanoidRootPart" and player.Character.Humanoid.Health > 0) then
				bbg.Adornee = player.Character.HumanoidRootPart
				info.Adornee = player.Character.HumanoidRootPart
				forhealth.Adornee = player.Character.HumanoidRootPart
				if (player.Team ~= localplayer.Team) then
					bbg.Enabled = true
					info.Enabled = true
					forhealth.Enabled = true
				end
				if cheats.Boundingbox == true then
					outlines.Visible = true
				else
					outlines.Visible = false
				end
				if cheats.Showhealth == true then
					if (player.Character:FindFirstChild"Humanoid") then
						healthl.Text = "Health: "..math.floor(player.Character:FindFirstChild"Humanoid".Health)
						healthbar.bar.Size = UDim2.new(1,0,player.Character:FindFirstChild"Humanoid".Health/player.Character:FindFirstChild"Humanoid".MaxHealth,0)
					end
					if cheats.b_ht == "Text" then
						healthbar.Visible = false
						healthl.Visible = true
					end
					if cheats.b_ht == "Bar" then
						healthl.Visible = false
						healthbar.Visible = true
					end
					if cheats.b_ht == "Both" then
						healthl.Visible = true
						healthbar.Visible = true
					end
				else
					healthl.Visible = false
					healthbar.Visible = false
				end
				if cheats.Showname then
					namelabel.Visible = true
				else
					namelabel.Visible = false
				end
				if cheats.Showdistance == true then
					distancel.Visible = true
					if (localplayer.Character and localplayer.Character:FindFirstChild"HumanoidRootPart") then
						distancel.Text = "Distance: "..math.floor(0.5+(localplayer.Character:FindFirstChild"HumanoidRootPart".Position - player.Character:FindFirstChild"HumanoidRootPart".Position).magnitude)
					end
				else
					distancel.Visible = false
				end
				if cheats.EnablTeamCheck == true then
					if (player.Team == localplayer.Team) then
						bbg.Enabled = true
						info.Enabled = true
						forhealth.Enabled = true
					end
				else
					if (player.Team == localplayer.Team) then
						bbg.Enabled = false
						info.Enabled = false
						forhealth.Enabled = false
					end
				end
				if cheats.UseTeamColor == true then
					left.BackgroundColor3 = player.TeamColor.Color
					right.BackgroundColor3 = player.TeamColor.Color
					up.BackgroundColor3 = player.TeamColor.Color
					down.BackgroundColor3 = player.TeamColor.Color
					healthl.TextColor3 = player.TeamColor.Color
					distancel.TextColor3 = player.TeamColor.Color
					namelabel.TextColor3 = player.TeamColor.Color
				else
					left.BackgroundColor3 = Color3.fromRGB(255,255,255)
					right.BackgroundColor3 = Color3.fromRGB(255,255,255)
					up.BackgroundColor3 = Color3.fromRGB(255,255,255)
					down.BackgroundColor3 = Color3.fromRGB(255,255,255)
					healthl.TextColor3 = Color3.fromRGB(255,255,255)
					distancel.TextColor3 = Color3.fromRGB(255,255,255)
					namelabel.TextColor3 = Color3.fromRGB(255,255,255)
				end
			else
				bbg.Enabled = false
				info.Enabled = false
				forhealth.Enabled = false
				
				bbg.Adornee = nil
				info.Adornee = nil
				forhealth.Adornee = nil
			end
			if not (game:GetService"Players":FindFirstChild(player.Name)) then
				espf:FindFirstChild(player.Name):Destroy()
				coroutine.yield()
			end
		end
	end)
	coroutine.resume(co)
end

do
	wait(2)

	for _,button in pairs(HEBOXESP:GetDescendants()) do
		if button:IsA"TextButton" then
			button.MouseButton1Click:connect(function()
				if button.Name == "HealthType" then
					if cheats.b_ht == "Text" then
						cheats.b_ht = "Bar"
						HealthType.Text = "text, BAR, both"
					elseif cheats.b_ht == "Bar" then
						cheats.b_ht = "Both"
						HealthType.Text = "text, bar, BOTH"
					else
						cheats.b_ht = "Text"
						HealthType.Text = "TEXT, bar, both"
					end
				else
					if cheats[button.Name] == true then
						cheats[button.Name] = false
						button.BackgroundColor3 = Color3.fromRGB(52, 52, 52)
					else
						cheats[button.Name] = true
						button.BackgroundColor3 = Color3.fromRGB(2, 54, 8)
					end
				end	
			end)
		end
	end
end

for i,plr in pairs(game.Players:GetChildren()) do
	if plr ~= localplayer then
		AddBox(plr)
	end
end

game.Players.PlayerAdded:Connect(function(plr)
	if plr ~= localplayer then
		AddBox(plr)
	end
end)